# Seminarios_ISGI_2021
## Código de los seminarios de OpenGL en ISGI/ETSINF/UPV
### Instalación
Para instalar *clonar* el proyecto usando git en la consola sobre el directorio preferido, por ejemplo $USER/source/repos   
`$ cd $USER/source/repos`   
`$ git clone -b main htpps://github.com/RobVivo/Seminarios_ISGI_2021`   
`$ cd Seminarios_ISGI_2021`   
`$ git submodule update --init`   
### Actualización
`$ cd $USER/source/repos/Seminarios_ISGI_2021`    
`$ git pull origin main`   
