// Ejemplo de uso de operadores aritmeticos
//-----------------------------------------
int main()
{
  int a;

  read(a);
  a = (((a + a) * 2) / 2) - a;
  print(a);

  return 0;
}
