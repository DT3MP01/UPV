// Ejemplo de uso de operadores aritmeticos
//-----------------------------------------
int main()
{
  int a;
  a = 1;
  loop
  print(a);
  counting 5;
  return 0;
}
