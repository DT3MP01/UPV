﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Avión : MonoBehaviour
{
    float velocidadAngular = 60.0f; //en grados por segundo

}
