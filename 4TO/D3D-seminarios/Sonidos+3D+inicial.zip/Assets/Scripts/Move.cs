﻿using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour {

	public Rigidbody rb;
    public float VertForce, //Vertical force applied on the object
                 HorForce; 	//Horizontal force applied on the object
}
