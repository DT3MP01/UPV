package org.opt4j.tutorial.minones;

import java.util.ArrayList;

public class MinOnesResult extends ArrayList<Boolean> {
	private static final long serialVersionUID = 1L;

}
