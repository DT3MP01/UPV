function [ x ] = miraizg( a,b,c )
x=(-b+sqrt(complex(b*b-4*a*c,0)))/(2*a)
end