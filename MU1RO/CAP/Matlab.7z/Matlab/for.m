function piresult = for(N)
    if (xcoord(i)^2 + ycoord(i)^2 <= 1)
        total_inside=total_inside+1;
    end