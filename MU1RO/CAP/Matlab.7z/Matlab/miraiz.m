function x=miraiz (a,b,c)
sol=roots([a,b,c]);
x=sol(1);
end