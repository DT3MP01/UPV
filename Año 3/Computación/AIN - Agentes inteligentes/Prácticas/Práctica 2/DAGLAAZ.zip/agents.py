import math
import random
from pygomas.bdifieldop import BDIFieldOp
from pygomas.bdisoldier import BDISoldier
from pygomas.bdimedic import BDIMedic
from agentspeak.stdlib import actions

class SoldierAndGeneral(BDISoldier):
    def add_custom_actions(self, actions):
        super().add_custom_actions(actions)
        @actions.add_function(".checkPoints", (tuple))
        def checkPoints(pList):
            '''
            Checks if it can be walked in the elements of the list of tuples.

            pList: list of tuples with positions.

            return: new tuple with walkable positions.
            '''
            res = []
            for point in pList:
                point = list(point)
                sx = 1
                sz = 1
                cont = 2
                while self.map.can_walk(point[0], point[2]) == False:
                    if cont % 2 == 1:
                        point[0] = point[0] + sx * int(cont / 2)
                        sx *= -1
                    else:
                        point[2] = point[2] + sz * int(cont / 2)
                        sz *= -1
                    cont += 1
                res.append((point[0], point[1], point[2]))
            return tuple(res)

class Medic(BDIMedic):
    def add_custom_actions(self, actions):
        super().add_custom_actions(actions)
        @actions.add_function(".checkPoints", (tuple))
        def checkPoints(pList):
            '''
            Checks if it can be walked in the elements of the list of tuples.

            pList: list of tuples with positions.

            return: new tuple with walkable positions.
            '''
            res = []
            for point in pList:
                point = list(point)
                sx = 1
                sz = 1
                cont = 2
                while self.map.can_walk(point[0], point[2]) == False:
                    if cont % 2 == 1:
                        point[0] = point[0] + sx * int(cont / 2)
                        sx *= -1
                    else:
                        point[2] = point[2] + sz * int(cont / 2)
                        sz *= -1
                    cont += 1
                res.append((point[0], point[1], point[2]))
            
            return tuple(res)

class Fieldop(BDIFieldOp):
    def add_custom_actions(self, actions):
        super().add_custom_actions(actions)
        @actions.add_function(".checkPoints", (tuple))
        def checkPoints(pList):
            '''
            Checks if it can be walked in the elements of the list of tuples.

            pList: list of tuples with positions.

            return: new tuple with walkable positions.
            '''
            res = []
            for point in pList:
                point = list(point)
                sx = 1
                sz = 1
                cont = 2
                while self.map.can_walk(point[0], point[2]) == False:
                    if cont % 2 == 1:
                        point[0] = point[0] + sx * int(cont / 2)
                        sx *= -1
                    else:
                        point[2] = point[2] + sz * int(cont / 2)
                        sz *= -1
                    cont += 1
                res.append((point[0], point[1], point[2]))
            return tuple(res)

@actions.add_function(".removePos", (int, tuple))
def removePos(p, l):
    '''
        Remove the p element of the list
        p: position to remove.
        l: list.

        return: list without the p element.
    '''
    if p == 0:
        return l[1:]
    elif p == (len(l) - 1):
        return l[:p]
    else:
        return tuple(l[0:p] + l[p + 1:])

@actions.add_function(".nearestAgent", (int,tuple, tuple))
def nearestAgent(ammount, agent, agents_positions):
    '''
        Obtains the positions of the nearest agents.

        ammount: number of agents to return.
        agent: Position of the unit seeking for help.
        posicion_agentes: List of agent positions.

        return: 'ammount' positions closest to the agent.
    '''
    distance_to_each_agent = []

    for agent_position in agents_positions:
        # Calculating the agent-to-agent distance
        distance_to_each_agent += [math.sqrt(math.pow(
            agent_position[0] - agent[0], 2) + math.pow(agent_position[2] - agent[2], 2))]

    # Sorting them by distance
    aux_distance = tuple(sorted(distance_to_each_agent))
    res = []

    if len(aux_distance) > ammount:
        for i in range(ammount):
            res += [distance_to_each_agent.index(aux_distance[i])]
    
    return tuple(res)

@actions.add_function(".patrollingPoint", (int, tuple))
def patrollingPoint(patrolling_distance, patrolling_point):
    '''
        Generates 4 points to patrol around 'patrolling_point'.

        patrolling_distance: Distance from the point to patrol.
        point: tuple with the position to patrol. 

        return: List of points to patrol.
    '''

    # Creating 4 patrol points
    a = [patrolling_point[0] - patrolling_distance,
            patrolling_point[1], patrolling_point[2]]

    b = [patrolling_point[0], patrolling_point[1],
            patrolling_point[2] - patrolling_distance]

    c = [patrolling_point[0] + patrolling_distance,
            patrolling_point[1], patrolling_point[2]]

    d = [patrolling_point[0], patrolling_point[1],
            patrolling_point[2] + patrolling_distance]

    positions = [tuple(a), tuple(b), tuple(c), tuple(d)]
    # Randomising the positions
    positions = random.sample(positions, len(positions))

    return tuple(positions)

@actions.add_function(".friendlyFire", (tuple, tuple, tuple))
def friendlyFire(myPos, enemyPos, friendPos):
    '''
        Checking whether friendPos is in the intersection between enemyPos and myPos.

        myPos: tuple with the agent position calling the function.
        enemyPos: tuple with the enemy position.
        friendPos: tuple with the friend position.

        return: True or False.
    '''
    crossproduct = (friendPos[2] - myPos[2]) * (enemyPos[0] - myPos[0]) - (
        friendPos[0] - myPos[0]) * (enemyPos[2] - myPos[2])

    if abs(crossproduct) > 0:
        return False

    dotproduct = (friendPos[0] - myPos[0]) * (enemyPos[0] - myPos[0]) + (
        friendPos[2] - myPos[2]) * (enemyPos[2] - myPos[2])

    if dotproduct < 0:
        return False

    squaredlengthba = (enemyPos[0] - myPos[0]) * (enemyPos[0] - myPos[0]) + (
        enemyPos[2] - myPos[2]) * (enemyPos[2] - myPos[2])

    if dotproduct > squaredlengthba:
        return False

    return True

@actions.add_function(".newGeneralElection", (tuple))
def newGeneralElection(soldiers):
    '''
        Electing new general from among the soldiers.

        soldiers: tuple containing all soldier identifiers. 

        return: ID of new general or 0.
    '''
    max = str(soldiers[0])
    
    for soldier in soldiers:
        if not isinstance(soldier, str):
            myid = soldier

        aux = str(soldier)

        if max < aux:
            max = aux
    
    if str(myid) == max:
        return myid
    else:
        return 0
