﻿using System;

public class Class1
{
	public Class1()
	{
		Console.log("hola1");
	}
}
