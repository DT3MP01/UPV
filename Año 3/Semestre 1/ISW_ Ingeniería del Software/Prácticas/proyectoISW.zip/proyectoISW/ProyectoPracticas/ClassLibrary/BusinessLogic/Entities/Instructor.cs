﻿using System;
using System.Collections.Generic;

namespace GestDep.Entities
{
    public partial class Instructor
    {
        public Instructor()
        {
            Activities = new List<Activity>();
        }
        public Instructor(string address, string iban, string id, string name,
        int zipCode, String ssn) : base(address, iban, id, name, zipCode)
        {
            Ssn = ssn;
            Activities = new List<Activity>();
        }
        public void AddActivity(Activity activity)
        {
            Activities.Add(activity);

        }
        public bool InstructorIsCorrect()
        {
            if (Address == "" || IBAN == "" || Id == "" || Name == ""
                || ZipCode <= 0)
            {

                return false;

            }

            return true;
        }


        public bool InstructorIsAvailable(Activity activity)
        {
            //debemos devolver una lista con los instructores disponibles
            bool instructorDisponible = true;
            foreach (Activity activities in Activities)
            {   // si activity.StartDate > activities.FinishDate o activity.FinishDate < activities.StartDate
                //la activity sucede en fechas antes o despues de activities por lo que  hay problema si coinciden
                if (!(activity.StartDate.CompareTo(activities.FinishDate) > 0
                    || activity.FinishDate.CompareTo(activities.StartDate) < 0))
                {
                    //Si ademas de que coinciden ,  activity  coincide en almenos un dia con activities
                    if ((activity.ActivityDays & activities.ActivityDays) != 0)
                    {
                        // y , coinciden en la hora , el instructor no estará disponible
                        if (activity.StartHour.CompareTo(activities.StartHour + activities.Duration) < 0
                            || activities.StartHour.CompareTo(activity.StartHour + activity.Duration) < 0)
                        {
                            instructorDisponible = false;
                        }
                    }
                }
            }

            return instructorDisponible;
        }
    }
}
