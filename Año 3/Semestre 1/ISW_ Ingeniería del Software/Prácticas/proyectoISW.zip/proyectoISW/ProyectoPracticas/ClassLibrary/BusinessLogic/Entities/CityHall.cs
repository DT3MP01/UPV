﻿using System;
using System.Collections.Generic;

namespace GestDep.Entities
{
    public partial class CityHall
    {
        public CityHall()
        {
            Payments = new List<Payment>();
            People = new List<Person>();
            Gyms = new List<Gym>();
        }

        public CityHall(String name) : this()
        {
            Name = name;
        }

        public void AddPeople(Person people)
        {
            People.Add(people);
        }
        public void AddPayment(Payment payment)
        {
            Payments.Add(payment);
        }
        public ICollection<string> InstructorsAvailableIds(Days activityDays, TimeSpan duration, DateTime finishDate, DateTime startDate, DateTime startHour)
        {
            //debemos devolver una lista con los instructores disponibles
            ICollection<string> instructoresDisponibles = new List<string>();

            foreach (Instructor instructor in People)
            {
                bool instructorDisponible = true;
                foreach (Activity activities in instructor.Activities)
                {   // si activity.StartDate > activities.FinishDate o activity.FinishDate < activities.StartDate
                    //la activity sucede en fechas antes o despues de activities por lo que  hay problema si coinciden
                    if (!(startDate.CompareTo(activities.FinishDate) > 0
                        || finishDate.CompareTo(activities.StartDate) < 0))
                    {
                        //Si ademas de que coinciden ,  activity  coincide en almenos un dia con activities
                        if ((activityDays & activities.ActivityDays) != 0)
                        {
                            // y , coinciden en la hora , el instructor no estará disponible
                            if (startHour.CompareTo(activities.StartHour + activities.Duration) < 0
                                || activities.StartHour.CompareTo(startHour + duration) < 0)
                            {
                                instructorDisponible = false;
                            }
                        }
                    }
                }

                if (instructorDisponible)
                {
                    instructoresDisponibles.Add(instructor.Id);
                }
            }
            return instructoresDisponibles;
        }
        public bool ExistsUser(string dni)
        {
            foreach (Person user1 in People)
            {
                if (user1.Id.Equals(dni))
                {
                    return true;
                }
            }
            return false;
        }

        public Instructor GetInstructorById(string instructorId)
        {
            foreach (Person instructor in People)
            {
                if (instructor.Id == instructorId && instructor is Instructor)
                {
                    return (Instructor)instructor;
                }
            }
            return null;
        }

        public User GetUserById(string userId)
        {
            foreach (Person user in People)
            {
                if (user.Id == userId && user is User)
                {
                    return (User)user;
                }
            }
            return null;
        }

        public Payment GetPaymentById(int paymentId)
        {
            foreach (Payment payment in Payments)
            {
                if (payment.Id == paymentId)
                {
                    return payment;
                }
            }
            return null;
        }

        public static double GetPrice(User user, Gym gym, Activity activity)
        {
            double price = activity.Price;
            if (user.ZipCode.Equals(gym.ZipCode))
            {
                if (user.Retired == true)
                {
                    price *= 0.8;
                }
                else
                {
                    price *= 0.9;
                }
            }
            else if (user.Retired == true)
            {
                price *= 0.9;
            }
            return price;
        }

        public static bool UserAlreadyInActivity(User user, Activity activity)
        {
            foreach (Enrollment enrollment in user.Enrollments)
            {
                if (enrollment.Activity.Equals(activity))
                {
                    return true;
                }
            }
            return false;
        }


    }
}