﻿using System;
using System.Collections.Generic;
using System.Linq;
using GestDep.Entities;
using GestDep.Persistence;

namespace GestDep.Services
{
    public class GestDepService : IGestDepService
    {
        private readonly IDAL dal; // Persistence Layer Interface
        public CityHall cityHall;  // Services only work on a City Hall
        public Gym gym;            // Gym of the City Hall. Also available from cityHall.Gyms.First();

        /// </summary>
        /// Returns a service Layer connected with the persistence Layer. Retrieves the CitiHall and Gym from the database if they exist. If not, it creates new ones
        /// </summary>
        /// <param name="dal"> Persistence Layer Interface</param>

        public GestDepService(IDAL dal)
        {
            this.dal = dal;
            try
            {

                if (dal.GetAll<CityHall>().Count() == 0) // No cityHall in the system. Data initilization. 
                {
                    bool CLEAR_DATABASE = true;
                    int ROOMS_NUMBER = 9;
                    int INSTRUCTORS_NUMBER = 5;
                    Populate populateDB = new Populate(CLEAR_DATABASE, dal);
                    cityHall = populateDB.InsertCityHall();
                    gym = populateDB.InsertGym(cityHall);     // Also in cityHall.First();                
                    populateDB.InsertRooms(ROOMS_NUMBER, gym);  // Now available from gym.rooms;
                    populateDB.InsertInstructors(INSTRUCTORS_NUMBER, cityHall); // Now available from cityHall.People;

                }
                else
                {   // Retrieve the CityHall stored
                    cityHall = dal.GetAll<CityHall>().First();

                    if (cityHall.Gyms.Count > 0)
                    { // Retrieve the Gym stored
                        gym = cityHall.Gyms.First();
                    }
                    else
                    { // Adding Rooms and Gym
                        bool MANTAIN_DATABASE = false;
                        int ROOMS_NUMBER = 9;
                        Populate populateDB = new Populate(MANTAIN_DATABASE, dal);
                        gym = populateDB.InsertGym(cityHall);
                        populateDB.InsertRooms(ROOMS_NUMBER, gym);
                    }
                    int INSTRUCTORS_NUMBER = 5;
                    if (dal.GetAll<Instructor>().Count() == 0) // No instructors
                    {
                        bool MANTAIN_DATABASE = false;
                        Populate populateDB = new Populate(MANTAIN_DATABASE, dal);
                        populateDB.InsertInstructors(INSTRUCTORS_NUMBER, cityHall); // Now available from cityHall.People;
                    }

                }
            }
            catch (Exception e)
            {
                throw new ServiceException("Error in the service init process", e);
            }
        }

        public int AddNewActivity(Days activityDays, string description, TimeSpan duration, DateTime finishDate, int maximumEnrollments, int minimumEnrollments, double price, DateTime startDate, DateTime startHour, ICollection<int> roomsIds)
        {
            Room room;
            Activity activity = new Activity(activityDays, description, duration, finishDate, maximumEnrollments, minimumEnrollments, price, startDate, startHour);
            // Comprobamos valores de la actividad que no sean negativos asi como las fechas de comienzo y finalizacion de la actividad

            if (!activity.ActivityIsCorrect())
            {
                throw new ServiceException("No se puede crear la actividad, datos incorrectos");
            }

            // roomsIds tiene al menos 1 elemento
            if (roomsIds == null)
            {
                throw new ServiceException("Introducir, al menos, una habitación para la actividad");
            }

            // Agregamos a la actividad las rooms en la lista de roomsIds 
            foreach (int roomId in roomsIds)
            {
                room = gym.GetRoomById(roomId);
                if (room == null)
                {
                    throw new ServiceException("La habitación: " + roomId + " no existe");
                }
                activity.AddRoom(room);
            }
            // Comprobamos que las habitaciones estan libres
            if (!gym.ActivityCheckHourRooms(activity))
            {
                throw new ServiceException("La actividad se programa en fechas en las que las salas están ocupadas");
            }

            // Añadimos la actividad al dal y a gym 
            dal.Insert(activity);
            gym.AddActivity(activity);
            SaveChanges();
            return activity.Id;
        }

        public void AddNewUser(string address, string iban, string id, string name, int zipCode, DateTime birthDate, bool retired)
        {
            User user = new User(address, iban, id, name, zipCode, birthDate, retired);

            if (!user.UserIsCorrect())
            {
                throw new ServiceException("Datos erroneos");
            }
            if (cityHall.ExistsUser(user.Id))
            {
                throw new ServiceException("El usuario ya existe en la base de datos");
            }

            // Agregar al nuevo usuario a la lista People
            cityHall.AddPeople(user);
            dal.Insert(user);
            SaveChanges();
        }

        public void AssignInstructorToActivity(int activityId, string instructorId)
        {
            Activity activity = gym.GetActivityById(activityId);

            if (activity == null)
            {
                throw new ServiceException("La actividad no existe");
            }

            Instructor instructor = cityHall.GetInstructorById(instructorId);

            if (instructor == null)
            {
                throw new ServiceException("El instructor no existe");
            }

            if (!instructor.InstructorIsAvailable(activity))
            {
                throw new ServiceException("El instructor no esta disponible");
            }

            activity.SetInstructor(instructor);
            instructor.AddActivity(activity);
            SaveChanges();
        }

        public int EnrollUserInActivity(int activityId, string userId)
        {
            Activity activity = gym.GetActivityById(activityId);

            if (activity == null)
            {
                throw new ServiceException("La actividad no existe");
            }

            if (!User.IdIsCorrect(userId))
            {
                throw new ServiceException("DNI no valido");
            }

            User user = cityHall.GetUserById(userId);
            double price = GetUserDataNotInActivityAndFirstQuota(activityId, userId, out string address, out string iban, out string name, out int zipCode, out DateTime birthDate, out bool retired, out ICollection<int> enrollmentIds);
            Payment payment = new Payment(DateTime.Now, "Pago de la actividad: " + activity.Id, price);
            cityHall.AddPayment(payment);
            Enrollment enrollment = new Enrollment(DateTime.Now, activity, payment, user);
            user.AddEnrollment(enrollment);
            activity.AddEnrollment(enrollment);
            dal.Insert(enrollment);
            SaveChanges();
            return enrollment.Id;
        }

        public void GetActivityDataFromId(int ActivityId, out Days activityDays, out string description, out TimeSpan duration, out DateTime finishDate, out int maximumEnrollments, out int minimumEnrollments, out double price, out DateTime startDate, out DateTime startHour, out ICollection<int> enrollmentIds, out string instructorId, out ICollection<int> roomIds)
        {
            Activity activity = gym.GetActivityById(ActivityId);

            if (activity == null)
            {
                throw new ServiceException("La actividad no existe");
            }

            activityDays = activity.ActivityDays;
            description = activity.Description;
            duration = activity.Duration;
            finishDate = activity.FinishDate;
            maximumEnrollments = activity.MaximumEnrollments;
            minimumEnrollments = activity.MinimumEnrollments;
            price = activity.Price;
            startDate = activity.StartDate;
            startHour = activity.StartHour;
            enrollmentIds = activity.GetEnrollmentsListIds();
            instructorId = activity.GetInstructor().Id;
            roomIds = activity.GetRoomsListIds();
        }

        public ICollection<int> GetAllActivitiesIds()
        {
            ICollection<Activity> list = new List<Activity>();
            list = gym.GetAllActivities();
            if (list == null)
            {
                throw new ServiceException("La lista de actividades esta vacia");
            }
            return Activity.GetActivitiesIds(list);
        }

        public ICollection<int> GetAllRunningOrFutureActivitiesIds()
        {
            ICollection<int> runningOrFutureActivitiesIds = new List<int>();
            runningOrFutureActivitiesIds = gym.GetAllRunningOrFutureActivities();
            if (runningOrFutureActivitiesIds.Count == 0)
            {
                throw new ServiceException("No hay ninguna Actividad disponible ahora mismo");
            }
            return runningOrFutureActivitiesIds;
        }

        public ICollection<string> GetAvailableInstructorsIds(Days activityDays, TimeSpan duration, DateTime finishDate, DateTime startDate, DateTime startHour)
        {
            if (!Activity.DateIsCorrect(activityDays, duration, finishDate, startDate, startHour))
            {
                throw new ServiceException("Fechas incorrectas");
            }

            ICollection<string> list = cityHall.InstructorsAvailableIds(activityDays, duration, finishDate, startDate, startHour);

            if (list == null)
            {
                throw new ServiceException("No hay instructores disponibles en esas fechas");
            }

            return list;
        }

        public void GetEnrollmentDataFromIds(int activityId, int enrollmentId, out DateTime? cancellationDate, out DateTime enrollmentDate, out DateTime? returnedFirstCuotaIfCancelledActivity, out ICollection<int> paymentIds, out string userId)
        {
            Activity activity = gym.GetActivityById(activityId);

            if (activity == null)
            {
                throw new ServiceException("La actividad no existe");
            }

            Enrollment enrollment = activity.GetEnrollmentById(enrollmentId);

            if (enrollment == null)
            {
                throw new ServiceException("La inscripción no existe");
            }

            cancellationDate = enrollment.CancellationDate;
            enrollmentDate = enrollment.EnrollmentDate;
            returnedFirstCuotaIfCancelledActivity = enrollment.ReturnedFirstCuotaIfCancelledActivity;
            paymentIds = enrollment.GetPaymentsIds();
            userId = enrollment.User.Id;
        }

        public void GetGymData(out int gymId, out DateTime closingHour, out int discountLocal, out int discountRetired, out double freeUserPrice, out string name, out DateTime openingHour, out int zipCode, out ICollection<int> activityIds, out ICollection<int> roomIds)
        {
            if (gym == null)
            {
                throw new ServiceException("CityHall no tiene gimnasios");
            }
            gymId = gym.Id;
            closingHour = gym.ClosingHour;
            discountLocal = gym.DiscountLocal;
            discountRetired = gym.DiscountRetired;
            freeUserPrice = gym.FreeUserPrice;
            name = gym.Name;
            openingHour = gym.OpeningHour;
            zipCode = gym.ZipCode;
            activityIds = gym.GetActivitiesIds();
            roomIds = gym.GetRoomsIds(); ;
        }

        public void GetInstructorDataFromId(string instructorId, out string address, out string IBAN, out string name, out int zipCode, out string ssn, out ICollection<int> activitiesIds)
        {
            Instructor instructor = cityHall.GetInstructorById(instructorId);
            if (instructor == null)
            {
                throw new ServiceException("El instructor no existe");
            }
            address = instructor.Address;
            IBAN = instructor.IBAN;
            name = instructor.Name;
            zipCode = instructor.ZipCode;
            ssn = instructor.Ssn;
            activitiesIds = gym.GetActivitiesIds();
        }

        public ICollection<int> GetListAvailableRoomsIds(Days activityDays, TimeSpan duration, DateTime finishDate, DateTime startDate, DateTime startHour)
        {
            if (!Activity.DateIsCorrect(activityDays, duration, finishDate, startDate, startHour))
            {
                throw new ServiceException("Datos erroneos de la actividad");
            }

            ICollection<int> roomsAvailable = gym.GetAvailableRoomsIds(activityDays, duration, finishDate, startDate, startHour);

            if (roomsAvailable == null)
            {
                throw new ServiceException("No hay habitaciones disponibles para la actividad");
            }

            return roomsAvailable;
        }

        public Dictionary<DateTime, int> GetListAvailableRoomsPerWeek(DateTime initialMonday)
        {
            if (initialMonday.DayOfWeek != DayOfWeek.Monday)
            {
                throw new ServiceException("La fecha dada no es Lunes");
            }

            return gym.GetAvaliableRoomsPerWeek(initialMonday);
        }

        public void GetPaymentDataFromId(int paymentId, out DateTime date, out string description, out double quantity)
        {
            Payment payment = cityHall.GetPaymentById(paymentId);

            if (payment == null)
            {
                throw new ServiceException("El pago no existe");
            }

            date = payment.Date;
            description = payment.Description;
            quantity = payment.Quantity;
        }

        public void GetRoomDataFromId(int roomId, out int number, out ICollection<int> activityIds)
        {
            Room room = gym.GetRoomById(roomId);

            if (room == null)
            {
                throw new ServiceException("La habitación no existe");
            }

            number = room.Number;
            activityIds = room.GetActivitiesIds();
        }

        public void GetUserDataFromId(string userId, out string address, out string iban, out string name, out int zipCode, out DateTime birthDate, out bool retired, out ICollection<int> enrollmentIds)
        {
            if (!User.IdIsCorrect(userId))
            {
                throw new ServiceException("Introducir un DNI valido");
            }

            User user = cityHall.GetUserById(userId);

            if (user == null)
            {
                throw new ServiceException("El usuario no existe");
            }

            address = user.Address;
            iban = user.IBAN;
            name = user.Name;
            zipCode = user.ZipCode;
            birthDate = user.BirthDate;
            retired = user.Retired;
            enrollmentIds = user.GetEnrollmentsIds();

        }

        public double GetUserDataNotInActivityAndFirstQuota(int activityId, string userId, out string address, out string iban, out string name, out int zipCode, out DateTime birthDate, out bool retired, out ICollection<int> enrollmentIds)
        {
            User user = cityHall.GetUserById(userId);

            if (user == null)
            {
                throw new ServiceException("El usuario no existe");
            }

            Activity activity = gym.GetActivityById(activityId);

            if (activity == null)
            {
                throw new ServiceException("La actividad no existe");
            }

            if (CityHall.UserAlreadyInActivity(user, activity))
            {
                throw new ServiceException("El usuario ya esta en la actividad");
            }

            address = user.Address;
            iban = user.IBAN;
            name = user.Name;
            zipCode = user.ZipCode;
            birthDate = user.BirthDate;
            retired = user.Retired;
            enrollmentIds = user.GetEnrollmentsIds();

            return CityHall.GetPrice(user, gym, activity);
        }

        #region Connection with the Persistence Layer
        public void RemoveAllData()
        {
            dal.RemoveAllData();
        }


        public void SaveChanges()
        {
            dal.Commit();
        }
        #endregion
    }
}
