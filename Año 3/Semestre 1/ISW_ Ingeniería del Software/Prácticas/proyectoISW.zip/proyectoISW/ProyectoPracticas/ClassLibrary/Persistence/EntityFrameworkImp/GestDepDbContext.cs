﻿using System.Data.Entity;
using GestDep.Entities;

namespace GestDep.Persistence
{
    public class GestDepDbContext : DbContextISW
    {
        public GestDepDbContext() : base("Name=GestDepDbConnection") { }

        public IDbSet<Activity> Activities { get; set; }
        public IDbSet<CityHall> CityHalls { get; set; }
        public IDbSet<Enrollment> Enrollments { get; set; }
        public IDbSet<Gym> Gyms { get; set; }
        public IDbSet<Instructor> Instructors { get; set; }
        public IDbSet<Payment> Payments { get; set; }
        public IDbSet<Person> People { get; set; }
        public IDbSet<Room> Rooms { get; set; }
        public IDbSet<User> Users { get; set; }


    }


}
