﻿using System;
using System.Collections.Generic;

namespace GestDep.Entities
{
    public partial class CityHall
    {
        public int Id
        {
            get;
            set;
        }

        public String Name
        {
            get;
            set;
        }

        // Associations

        public virtual ICollection<Gym> Gyms
        {
            get;
            set;
        }

        public virtual ICollection<Person> People
        {
            get;
            set;
        }

        public virtual ICollection<Payment> Payments
        {
            get;
            set;
        }
    }
}
