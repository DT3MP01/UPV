﻿using System.Collections.Generic;

namespace GestDep.Entities
{
    public partial class Room
    {
        public Room()
        {
            Activities = new List<Activity>();
        }
        public Room(int number) : this()
        {
            Number = number;
        }

        public ICollection<int> GetActivitiesIds()
        {
            ICollection<int> list = new List<int>();

            foreach (Activity activity in Activities)
            {
                list.Add(activity.Id);
            }
            return list;
        }
    }
}
