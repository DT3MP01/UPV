﻿using System;

namespace GestDep.Entities
{
    public partial class Payment
    {
        public Payment() { }

        public Payment(DateTime date, String description, double quantity)
        {
            Date = date;
            Description = description;
            Quantity = quantity;
        }


    }

}
