﻿using System;
using System.Collections.Generic;

namespace GestDep.Entities
{
    public partial class User : Person
    {
        public DateTime BirthDate
        {
            get;
            set;
        }
        public bool Retired
        {
            get;
            set;
        }

        // Associations
        public virtual ICollection<Enrollment> Enrollments
        {
            get;
            set;
        }
    }
}
