﻿using System;

namespace GestDep.Entities
{
    public partial class Payment
    {
        public DateTime Date
        {
            get;
            set;
        }
        public String Description
        {
            get;
            set;
        }

        public int Id
        {
            get;
            set;
        }
        public double Quantity
        {
            get;
            set;
        }
    }
}
