﻿using System.ComponentModel.DataAnnotations;

namespace GestDep.Entities
{
    public partial class Person
    {
        public string Address
        {
            get;
            set;
        }
        public string IBAN
        {
            get;
            set;
        }

        [Key]
        public string Id
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }
        public int ZipCode
        {
            get;
            set;
        }
    }
}