﻿using System;
using System.Collections.Generic;

namespace GestDep.Entities
{
    public partial class User
    {
        public User()
        {
            Enrollments = new List<Enrollment>();
        }
        public User(string address, string iban, string id, string name, int zipCode, DateTime birthDate, bool retired)
            : base(address, iban, id, name, zipCode)
        {
            BirthDate = birthDate;
            Retired = retired;
            Enrollments = new List<Enrollment>();
        }
        public void AddEnrollment(Enrollment enrollment)
        {
            Enrollments.Add(enrollment);
        }
        public bool UserIsCorrect()
        {
            if (Address == "" || IBAN == "" || Id == "" || Name == ""
                || ZipCode <= 0 || DateTime.Now.CompareTo(BirthDate) < 0 || !IdIsCorrect(Id))
            {
                return false;
            }

            return true;
        }
        public static bool IdIsCorrect(string id)
        {
            int number;
            if ((id.Length == 9) && (Int32.TryParse(id.Substring(0, 8), out number) && !Int32.TryParse(id.Substring(8), out number)))
            {
                return true;
            }

            return false;
        }

        public ICollection<int> GetEnrollmentsIds()
        {
            ICollection<int> enrollments = new List<int>();

            foreach (Enrollment enrollment in Enrollments)
            {
                enrollments.Add(enrollment.Id);
            }
            return enrollments;
        }

    }


}
