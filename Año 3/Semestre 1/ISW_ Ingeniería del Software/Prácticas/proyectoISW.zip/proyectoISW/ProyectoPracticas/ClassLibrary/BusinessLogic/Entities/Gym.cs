﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GestDep.Entities
{
    public partial class Gym
    {
        public Gym()
        {
            Rooms = new List<Room>();
            Activities = new List<Activity>();
        }

        public Gym(DateTime closingHour, int discountLocal, int discountRetired,
            double freeUserPrice, string name, DateTime openingHour,
            int zipCode) : this()
        {
            ClosingHour = closingHour;
            DiscountLocal = discountLocal;
            DiscountRetired = discountRetired;
            FreeUserPrice = freeUserPrice;
            Name = name;
            OpeningHour = openingHour;
            ZipCode = zipCode;
        }

        public bool ExistsActivity(Activity activity)
        {
            if (Activities.Contains(activity))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public void AddActivity(Activity activity)
        {
            Activities.Add(activity);
        }

        public bool ActivityCheckHourRooms(Activity activity)
        {
            bool habitacionDisponible = true;
            foreach (Activity activity1 in Activities)
            {
                //Si las actividades no coinciden ningun dia
                if (activity.StartDate.CompareTo(activity1.FinishDate) > 0 || activity.FinishDate.CompareTo(activity1.StartDate) < 0)
                {
                    //disponible , no hacemos nada
                }
                //Si  activity  coincide en almenos un dia con activity1
                else if ((activity.ActivityDays & activity1.ActivityDays) != 0)
                {
                    // y, si  coinciden en la hora 
                    if (activity.StartHour.CompareTo(activity1.StartHour + activity1.Duration) < 0
                        || activity1.StartHour.CompareTo(activity.StartHour + activity.Duration) < 0)
                    {
                        //comprobamos si comparten alguna habitación
                        foreach (Room room in Rooms)
                        {
                            if (activity.Rooms.Contains(room) && activity1.Rooms.Contains(room))
                            {
                                habitacionDisponible = false;
                            }
                        }
                    }
                }

            }
            return habitacionDisponible;
        }

        public bool ActivityCheckDate(Activity activity)
        {
            if (activity.StartDate.CompareTo(activity.FinishDate) < 0
                && activity.StartDate.CompareTo(DateTime.Now) > 0)
            {
                return true;
            }

            return false;
        }

        public Activity GetActivityById(int activityId)
        {
            foreach (Activity activity in Activities)
            {
                if (activity.Id == activityId)
                {
                    return activity;
                }
            }
            return null;
        }

        public ICollection<Activity> GetAllActivities()
        {
            return Activities;
        }

        public ICollection<Room> GetAllRooms()
        {
            return Rooms;
        }

        public Room GetRoomById(int roomId)
        {
            foreach (Room room in Rooms)
            {
                if (room.Id == roomId)
                {
                    return room;
                }
            }
            return null;
        }
        public ICollection<int> GetAllRunningOrFutureActivities()
        {
            ICollection<int> RoFactivities = new List<int>();
            foreach (Activity activity in Activities)
            {
                if (activity.StartDate.CompareTo(DateTime.Now) <= 0)
                {
                    if (activity.FinishDate.CompareTo(DateTime.Now) > 0)
                    {
                        RoFactivities.Add(activity.Id);
                    }
                }
                else
                {
                    RoFactivities.Add(activity.Id);
                }

            }
            return RoFactivities;
        }

        public ICollection<int> GetAvailableRoomsIds(Days activityDays, TimeSpan duration, DateTime finishDate, DateTime startDate, DateTime startHour)
        {

            ICollection<int> availableRooms = new List<int>();
            foreach (Room room in Rooms)
            {
                bool habitacionDisponible = true;

                foreach (Activity activity in room.Activities)
                {
                    if (!(startDate.CompareTo(activity.FinishDate) > 0
                          || finishDate.CompareTo(activity.StartDate) < 0))
                    {
                        // Si además de que coinciden,  activity  coincide en almenos un día con activities
                        if ((activityDays & activity.ActivityDays) != 0)
                        {
                            // y, coinciden en la hora, la habitación no estará disponible
                            if (startHour.CompareTo(activity.StartHour + activity.Duration) < 0
                                || activity.StartHour.CompareTo(startHour + duration) < 0)
                            {
                                habitacionDisponible = false;
                            }
                        }
                    }

                }

                if (habitacionDisponible)
                {
                    availableRooms.Add(room.Id);
                }

            }

            return availableRooms;
        }

        public ICollection<int> GetActivitiesIds()
        {
            ICollection<int> list = new List<int>();

            foreach (Activity activity in Activities)
            {
                list.Add(activity.Id);
            }
            return list;
        }

        public ICollection<int> GetRoomsIds()
        {
            ICollection<int> list = new List<int>();

            foreach (Room room in Rooms)
            {
                list.Add(room.Id);
            }
            return list;
        }

        public Dictionary<DateTime, int> GetAvaliableRoomsPerWeek(DateTime initialMonday)
        {
            Days day = Days.Mon | Days.Tue | Days.Wed | Days.Thu | Days.Fri | Days.Sat | Days.Sun;
            TimeSpan time = new TimeSpan(0, 45, 0);
            DateTime start = OpeningHour;
            ICollection<int> roomId;
            DateTime dt = initialMonday.Date;
            Dictionary<DateTime, int> dictionary = new Dictionary<DateTime, int>();

            for (int i = 1; i < 8; i++)
            {
                while (ClosingHour.CompareTo(start) > 0)
                {
                    roomId = GetAvailableRoomsIds(day, time, dt.AddDays(1), dt, start);
                    int hour = start.Hour;
                    int minutes = start.Minute;
                    dictionary.Add(dt.AddHours(hour).AddMinutes(minutes), roomId.Count());
                    start = start.AddMinutes(45);
                }

                start = OpeningHour;
                dt = initialMonday.Date.AddDays(i);
            }

            return dictionary;
        }
    }
}