﻿using System;
using System.Collections.Generic;

namespace GestDep.Entities
{
    public partial class Activity
    {
        public Activity()
        {
            Rooms = new List<Room>();
            Enrollments = new List<Enrollment>();
        }

        public Activity(Days activityDays, String description, TimeSpan duration, DateTime finishDate,
             int maximumEnrollments, int minimumEnrollments, double price,
            DateTime startDate, DateTime startHour) : this()
        {

            ActivityDays = activityDays;
            Cancelled = false;
            Description = description;
            Duration = duration;
            FinishDate = finishDate;

            MaximumEnrollments = maximumEnrollments;
            MinimumEnrollments = minimumEnrollments;
            Price = price;
            StartDate = startDate;
            StartHour = startHour;
        }

        public void SetInstructor(Instructor instructor)
        {
            Instructor = instructor;
        }

        public Instructor GetInstructor()
        {
            return Instructor;
        }

        public void AddEnrollment(Enrollment enrollment)
        {
            Enrollments.Add(enrollment);
        }

        public bool ActivityIsCorrect()
        {
            if (MinimumEnrollments < 0 || MaximumEnrollments < 0 || Duration.CompareTo(TimeSpan.Zero) < 0
                 || Price < 0 || ActivityDays.Equals(Days.None) || MinimumEnrollments > MaximumEnrollments) { return false; }

            else if (StartDate.CompareTo(FinishDate) < 0)
            {
                if (StartDate.CompareTo(DateTime.Now) > 0)
                {
                    return true;
                }
            }

            return false;
        }
        public static bool DateIsCorrect(Days activityDays, TimeSpan duration, DateTime finishDate, DateTime startDate, DateTime startHour)
        {
            if (duration.CompareTo(TimeSpan.Zero) < 0 || activityDays.Equals(Days.None)
                || finishDate.CompareTo(startDate) < 0 || DateTime.Now.CompareTo(finishDate) > 0 || DateTime.Now.CompareTo(startDate) >= 0)
            {
                return false;
            }
            return true;
        }

        public void AddRoom(Room room)
        {
            Rooms.Add(room);
        }


        public Boolean InstructorAssigned()
        {
            if (Instructor != null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public Boolean UserInActivity(User user)
        {
            foreach (Enrollment enrollment in Enrollments)
            {
                if (enrollment.User.Equals(user))
                {
                    return true;
                }
            }
            return false;
        }

        public Enrollment GetEnrollmentById(int enrollmentId)
        {
            foreach (Enrollment enrollment in Enrollments)
            {
                if (enrollment.Id.Equals(enrollmentId))
                {
                    return enrollment;
                }
            }
            return null;
        }

        public ICollection<int> GetEnrollmentsListIds()
        {
            ICollection<int> enrollmentListIds = new List<int>();

            foreach (Enrollment enrollment in Enrollments)
            {
                enrollmentListIds.Add(enrollment.Id);
            }

            return enrollmentListIds;
        }

        public ICollection<int> GetRoomsListIds()
        {
            ICollection<int> roomsListIds = new List<int>();

            foreach (Room room in Rooms)
            {
                roomsListIds.Add(room.Id);
            }

            return roomsListIds;
        }

        public static ICollection<int> GetActivitiesIds(ICollection<Activity> list)
        {
            ICollection<int> activitiesList = new List<int>();
            foreach (Activity activity1 in list)
            {
                activitiesList.Add(activity1.Id);
            }
            return activitiesList;
        }
    }
}
