﻿using System;
using System.Collections.Generic;

namespace GestDep.Entities
{
    public partial class Instructor : Person
    {
        public String Ssn
        {
            set;
            get;
        }

        // Associations 

        public virtual ICollection<Activity> Activities
        {
            get;
            set;
        }
    }
}
