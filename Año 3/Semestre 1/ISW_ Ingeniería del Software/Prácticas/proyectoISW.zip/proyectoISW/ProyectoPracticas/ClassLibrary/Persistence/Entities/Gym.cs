﻿using System;
using System.Collections.Generic;

namespace GestDep.Entities
{
    public partial class Gym
    {
        public DateTime ClosingHour
        {
            set;
            get;
        }

        public int DiscountLocal
        {
            set;
            get;
        }

        public int DiscountRetired
        {
            set;
            get;
        }

        public double FreeUserPrice
        {
            set;
            get;
        }

        public int Id
        {
            set;
            get;
        }

        public String Name
        {
            set;
            get;
        }

        public DateTime OpeningHour
        {
            set;
            get;
        }

        public int ZipCode
        {
            set;
            get;
        }

        // Associations
        public virtual ICollection<Activity> Activities
        {
            get;
            set;
        }

        public virtual ICollection<Room> Rooms
        {
            get;
            set;
        }




    }
}
