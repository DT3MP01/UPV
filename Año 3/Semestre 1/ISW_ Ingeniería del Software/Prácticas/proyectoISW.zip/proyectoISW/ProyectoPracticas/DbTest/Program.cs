﻿using System;
using System.Data.Entity.Validation;
using System.Linq;

using GestDep.Entities;
using GestDep.Persistence;

namespace DBTest
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                EntityFrameworkDAL dal = new EntityFrameworkDAL(new GestDepDbContext());
                new Program(dal);
            }
            catch (Exception e)
            {
                printError(e);
                Console.WriteLine("Press any key.");
                Console.ReadLine();
            }
        }

        public Program(IDAL dal)
        {
            createSampleDB(dal);
            Console.WriteLine("\n\n\n");
            displayData(dal);
        }

        static void printError(Exception e)
        {
            while (e != null)
            {
                if (e is DbEntityValidationException)
                {
                    DbEntityValidationException dbe = (DbEntityValidationException)e;

                    foreach (var eve in dbe.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Value: \"{1}\", Error: \"{2}\"",
                                ve.PropertyName,
                                eve.Entry.CurrentValues.GetValue<object>(ve.PropertyName),
                                ve.ErrorMessage);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("ERROR: " + e.Message);
                }
                e = e.InnerException;
            }
        }

        private void createSampleDB(IDAL dal)
        {
            // Remove all data from DB
            dal.RemoveAllData();

            CityHall cityHall = new CityHall("Valencia");
            dal.Insert(cityHall);
            dal.Commit();

            Gym gym = new Gym(Convert.ToDateTime("14:00:00"), 5, 5, 2.00, "Gym1", Convert.ToDateTime("08:00:00"), 46022);
            dal.Insert(gym);
            cityHall.Gyms.Add(gym);
            dal.Commit();

            Activity activity = new Activity(Days.Fri, "Descripción",
                new DateTime(2008, 6, 1, 8, 47, 0) - new DateTime(2008, 6, 1, 7, 47, 0),
                new DateTime(2008, 6, 1, 7, 47, 0), 50, 10, 99.99, new DateTime(2008, 6, 1, 8, 47, 0),
                new DateTime(2008, 6, 1, 7, 47, 0));
            dal.Insert(activity);
            gym.Activities.Add(activity);
            dal.Commit();

            // Populate here the rest of the database with data
            Room room = new Room(50);
            dal.Insert(room);
            room.Activities.Add(activity);
            activity.Rooms.Add(room);
            gym.Rooms.Add(room);
            dal.Commit();

            Payment payment = new Payment(new DateTime(2020, 1, 13, 3, 57, 32, 11), "Hola, soy un pago", 500);
            dal.Insert(payment);
            cityHall.Payments.Add(payment);
            dal.Commit();

            User user = new User("Valencia", "666", "111", "David", 46700, new DateTime(2000, 1, 13, 3, 57, 32, 11), false);
            dal.Insert(user);
            cityHall.People.Add(user);
            dal.Commit();

            Instructor instructor = new Instructor("Valencia", "444", "555", "Luis", 46700, "Ns");
            dal.Insert(instructor);
            cityHall.People.Add(instructor);
            instructor.Activities.Add(activity);
            activity.Instructor = instructor;
            dal.Commit();

            Enrollment enrollment = new Enrollment(new DateTime(2020, 1, 13, 3, 57, 32, 11), activity, payment, user);
            dal.Insert<Enrollment>(enrollment);
            activity.Enrollments.Add(enrollment);
            user.Enrollments.Add(enrollment);
            dal.Commit();
        }

        private void displayData(IDAL dal)
        {

            Console.WriteLine("===================================");
            Console.WriteLine("          CityHall details         ");
            Console.WriteLine("===================================");

            CityHall cityhall;
            cityhall = dal.GetAll<CityHall>().First();
            Console.WriteLine("Name: " + cityhall.Name + ", id = " + cityhall.Id);

            Console.WriteLine("Pres Key to exit...");
            Console.ReadKey();

            Console.WriteLine("===================================");
            Console.WriteLine("            Gym details            ");
            Console.WriteLine("===================================");

            foreach (Gym g in cityhall.Gyms)
            {
                Console.WriteLine("Name: " + g.Name + ", Opening Hour: " + g.OpeningHour + ", Closing Hour: " + g.ClosingHour);
            }

            Console.WriteLine("Pres Key to exit...");
            Console.ReadKey();

        }

        // Display here the information stored in the rest of the database tables
    }
}


