﻿using GestDep.Persistence;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace GestDepLogicDesignTest
{
    [TestClass]
    public class BaseTest
    {
        private protected EntityFrameworkDAL dal;

        [TestInitialize]
        public void IniTests()
        {
            dal = new EntityFrameworkDAL(new GestDepDbContext());
            dal.RemoveAllData();


        }

        [TestCleanup]
        public void CleanTests()
        {
            dal.RemoveAllData();
        }
    }
}
