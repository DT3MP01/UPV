/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   mips_fp.h
 * Author: plopez
 *
 * Created on 7 de noviembre de 2017, 9:51
 */

#ifndef MIPS_FP_H
#define MIPS_FP_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef CPROTO
#include "mips_fp_api.h"
#endif

#ifdef __cplusplus
}
#endif

#endif /* MIPS_FP_H */

