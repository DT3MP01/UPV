 int bloque_instruccion ( 
	dword PC
	 );
 void color_instruccion ( 
	char *color,
	dword PC
	 );
 void imprime_instruccion_color ( 
	char *instruc,
	dword PC,
	boolean encolor
	 );
