const efn= require('./eat.js');

efn.eatBreakfast();
efn.eatLunch();
efn.eatDinner();
efn.eatDessert();

