

const efn= require('./eat_prom.js');


// Using promises

efn.eatBreakfast().then(console.log).then(console.log);
