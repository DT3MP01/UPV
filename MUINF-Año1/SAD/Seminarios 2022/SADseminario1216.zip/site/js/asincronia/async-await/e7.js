const fs=require('fs')
function readFilePromise(filename) {
  return new Promise( (resolve,reject) => {
    fs.readFile(filename, (err,data) => {
      if (err) reject(err+'')
      else resolve(data+'')
    })
  })
}
async function readTwoFiles() {
  try {
    console.log(await readFilePromise("e7.js"))
    console.log(await readFilePromise("doesntExist.js"))                                                    
  } catch (err) {console.error(err+'')}
}
readTwoFiles()