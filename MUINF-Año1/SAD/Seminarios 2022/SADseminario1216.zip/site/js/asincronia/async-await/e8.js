const fs=require('fs')
function readFilePromise(filename) {
  return new Promise( (resolve,reject) => {
    fs.readFile(filename, (err,data) => {
      if (err) reject(err+'')
      else resolve(data+'')
    })
  })
}
async function readTwoFiles() {
    console.log(await readFilePromise("e8.js"))
    console.log(await readFilePromise("doesntExist.js"))
}
readTwoFiles().catch(console.error)