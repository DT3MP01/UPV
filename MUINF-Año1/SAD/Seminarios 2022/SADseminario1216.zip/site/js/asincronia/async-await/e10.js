const fsp = require('fs').promises
fsp.readFile('jsonFILE')
.then(text => {
  const obj = JSON.parse(text)
  console.log(JSON.stringify(obj))
})
.catch(error => {console.error(error)})
