const fs = require('fs')  // Supongo programa guardado en ./e5.js 
function readFilePromise(filename) {
  return new Promise( (resolve,reject) => { // creamos promesa con el constructor Promise(resolveFunc, rejectFunc)
    fs.readFile(filename, (err,data) => {  // funcion asincronica que quiero convertir en promesa
      if (err) reject(err+'')  // se rechaza
      else resolve(data+'')    // se satisface
    })
  })
}
readFilePromise("e5.js"         ).then(console.log, console.error) // callbaks si rechazada/satisfecha
readFilePromise("doesntExist.js").then(console.log, console.error)