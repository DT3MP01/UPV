function fibo(n) {
	return (n<2) ? 1 : fibo(n-2) + fibo(n-1)
}
function show(m, u) {console.log(m + ": The result is: " + u)}

console.log("Starting the process...")
setTimeout( () => {console.log("M1: My first message...")}, 10)
let j = fibo(42) // require several seconds
show("M2", j) 
setTimeout( () => {show("M3", j)}, 0)