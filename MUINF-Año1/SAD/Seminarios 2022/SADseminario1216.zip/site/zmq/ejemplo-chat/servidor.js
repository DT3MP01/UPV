const {zmq, lineaOrdenes, error, adios, creaPuntoConexion} = require('../tsr')
lineaOrdenes("portDifusion portEntrada")

let entrada = zmq.socket('pull')
let salida  = zmq.socket('pub')
creaPuntoConexion(salida, portDifusion)
creaPuntoConexion(entrada,portEntrada)

entrada.on('message', (type,id,txt) => {
	switch (type.toString()) {
		case 'HI':  salida.send(['SERVER', id+' connected']); break
		case 'BYE': salida.send(['SERVER', id+' disconnected']); break
		case 'MSG':  salida.send([id,txt])
		default: // error. No debe llegar aqui
	}
})

salida.on('error', (msg) => {error(`${msg}`)})
process.on('SIGINT', adios([entrada,salida],"abortado con CTRL-C"))