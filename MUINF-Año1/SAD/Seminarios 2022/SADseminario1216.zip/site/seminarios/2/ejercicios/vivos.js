const readln = require('readline')

const NUM_NODOS  = parseInt(process.argv[2]) ||    3
const MAX_ESPERA = parseInt(process.argv[3]) || 4000
if (NUM_NODOS==NaN || NUM_NODOS < 1 || NUM_NODOS > 10) {
	console.log('El número de nodos debe ser un entero entre 1 y 10')
	return
}
console.log(`Empezamos: ${NUM_NODOS} nodos, espera máxima ${MAX_ESPERA}`)

let failed = [] // para marcar qué nodos han fallado
let temp   = [] // temporizador para cada nodo (para saber cuándo vence su timeout)
let instante = 0
for (let i=0; i<NUM_NODOS; i++) {
	failed.push(false) // de momento no ha fallado ningún nodo
	temp.push(setTimeout(falla(i), MAX_ESPERA)) // pero cada uno fallará en MAX_ESPERA ms
}
setInterval(()=>{++instante}, 1000) // registra el paso del tiempo

readln.emitKeypressEvents(process.stdin)
process.stdin.setRawMode(true)

function falla(x) { // Devuelve la función a ejecutar cuando falla x
	return () => {  // clausura. ¿necesario?
		failed[x]=true // marcamos que dicho nodo ha fallado para poder descartar sus mensaje futuros
		console.log(`${instante}: El nodo ${x} ha fallado: quedan vivos ${failed.map((v,i)=>v?" - ":` ${i} `)}`)
		if (failed.reduce((a,b)=>a && b)) process.exit(0)
	}
}

process.stdin.on('keypress', k => { // tecla pulsada
	if (k<0 || k>=NUM_NODOS) return // ese nodo no existe
	console.log(k) // muestra el nodo que ha emitido el mensaje
	if (failed[k]) {
		console.log(`${instante}: descartado mensaje de ${k} (había fallado)`)
		return
	}
	console.log(`${instante}: ${k} sigue vivo`)
	clearTimeout(temp[k])  // cancela la programación de su función falla
	temp[k] = setTimeout(falla(k), MAX_ESPERA) // e inicia una nueva programación
})