Sample: Device Query
Minimum spec: GeForce 8

This sample enumerates the properties of the CUDA devices present in the system.

Key concepts:
CUDA Runtime API
Device Query
