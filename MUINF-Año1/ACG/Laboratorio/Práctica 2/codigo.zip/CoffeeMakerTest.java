 

import static org.junit.Assert.*;
import org.junit.*;
import java.util.*;


/**
 * @author Sarah E. Smith
 * @adjusted to JUnit 4 Tanja Vos
 */
public class CoffeeMakerTest {
	private CoffeeMaker cm;
	private Inventory i;
	private Recipe r1;
	
	@Before
	public void setUp() {
		cm = new CoffeeMaker();
		i = cm.checkInventory();
		
		r1 = new Recipe();
		r1.setName("Coffee");
		r1.setPrice(50);
		r1.setAmtCoffee(6);
		r1.setAmtMilk(1);
		r1.setAmtSugar(1);
		r1.setAmtChocolate(0);
	}
	
	@Test
	public void testAddRecipe() {
		assertTrue(cm.addRecipe(r1));
	}

}
