package logic;

public class Rental {

    private Movie movie;
    private Book book;
    private int daysRented;

    public Rental(Movie movie, int daysRented) {
        this.movie = movie;
        this.daysRented = daysRented;
    }

    public Rental(Book book, int daysRented) {
        this.book = book;
        this.daysRented = daysRented;
    }
    public Movie getMovie() {
        return movie;
    }
    public Book getBook() {
        return book;
    }

    public int getDaysRented() {
        return daysRented;
    }

    
}
