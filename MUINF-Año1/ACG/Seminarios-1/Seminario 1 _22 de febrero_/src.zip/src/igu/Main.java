package igu;

import logic.Customer;
import logic.Movie;
import logic.Rental;


public class Main {

	public static void main(String[] args) {
		
	    int diasAlquiler;
	    
		Rental m_Rental;
		Movie m_Movie;
		Customer m_Customer;
		
		m_Customer = Consola.obtenerCustomerDetails();
		m_Movie = Consola.obtenerMovieDetails();
		diasAlquiler = Consola.obtenerDiasAlquiler();
		m_Rental = new Rental(m_Movie, diasAlquiler);
	    m_Customer.addRental(m_Rental);
				
		m_Customer.statement();
		
	}

}
