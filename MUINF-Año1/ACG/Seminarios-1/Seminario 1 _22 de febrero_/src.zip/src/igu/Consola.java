package igu;
import java.util.*;

public class Consola {

	static String title;
	static String name;
	static logic.Book.PriceCodes priceBook;
	static logic.Movie.PriceCodes priceMovie;
	static int diasAlquiler;
	
	static Scanner in = new Scanner(System.in);
	
	static public logic.Book obtenerBookDetails() {
	    	int codigoPrecio;
		System.out.println("Introduzca el titulo del libro: ");
		title = in.nextLine();
		System.out.println("Introduzca 1 si es un libro para niños o 2 si es un nuevo lanzamiento o 0 si no es ninguno de los anteriores: ");
		codigoPrecio = in.nextInt();
		if (codigoPrecio ==0) priceBook = logic.Book.PriceCodes.Regular;
		if (codigoPrecio ==1) priceBook = logic.Book.PriceCodes.Childrens;
		if (codigoPrecio ==2) priceBook = logic.Book.PriceCodes.NewRelease;
		return new logic.Book(title, priceBook);
	}
	
	static public logic.Movie obtenerMovieDetails() {
    	int codigoPrecio;
	System.out.println("Introduzca el titulo de la película a alquilar: ");
	title = in.nextLine();
	System.out.println("Introduzca 1 si es una película para niños o 2 si es un nuevo lanzamiento o 0 si no es ninguno de los anteriores: ");
	codigoPrecio = in.nextInt();
	in.nextLine();
	if (codigoPrecio ==0) priceMovie = logic.Movie.PriceCodes.Regular;
	if (codigoPrecio ==1) priceMovie = logic.Movie.PriceCodes.Childrens;
	if (codigoPrecio ==2) priceMovie = logic.Movie.PriceCodes.NewRelease;
	return new logic.Movie(title, priceMovie);
	
}
	
	static public logic.Customer obtenerCustomerDetails() {
	System.out.println("Introduzca el nombre del cliente: ");
	name = in.nextLine();
	return new logic.Customer(name);
	
}
	
	static public int obtenerDiasAlquiler() {
		System.out.println("Introduzca los días de alquiler: ");
		diasAlquiler = in.nextInt();
		return diasAlquiler;
	}
	
	static public void volcarPantalla(String output) {
		System.out.println(output);
	}
}
