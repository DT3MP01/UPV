This is a demo of how an agent can create another agent, and 
how a separate java program (to be compiled separately, see 
file CreateAgDemo.java) can add an agent to an existing MAS.
