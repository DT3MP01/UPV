import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * An empty small world with a cat.
 * 
 * @author IIP
 * @version 2016-17
 */
public class CatWorld extends World {
    /**
     * Constructor for objects of class CatWorld.
     */
    public CatWorld() {    
        // Create a new world with 800x640 cells with a cell size of 1x1 pixels.
        super(800, 640, 1);
        // Add a new object of type Cat at position (cell) 730x328
        addObject (new Cat(), 730, 328);
    }
}
