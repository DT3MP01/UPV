import java.util.Scanner;
import miUtil.ValidarDatos;

/**
 * Clase Programa que lee un entero (int) positivo VALIDO de 
 * teclado, y muestra por pantalla sus cifras (primero unidades,
 * luego decenas, etc.) 
 * 
 * @author Mabel 
 * @version Octubre 2016
 */

public class CifrasDeUnNumero {
    public static void main(String[] args) { 
        
        System.out.println("--- Muestra por pantalla de las cifras de un "
                           + "entero positivo ---");
        Scanner teclado = new Scanner(System.in);
        
        int a = ValidarDatos.intPositivo(teclado);  
        
        System.out.println();
        // Invocacion al metodo mostrarCifras
        String cifrasDeA = mostrarCifras(a);
        // Se muestran por pantalla las cifras de a
        System.out.println("Las cifras de " + a 
                           + " son, de la ultima a la primera, ...\n" 
                           + cifrasDeA);
    }
   
    // PRECONDICION: a > 0
    // Devuelve un String con las cifras de a, cada una en una linea
    // distinta, de la ultima a la primera
    public static String mostrarCifras(int a) {
        String res = ""; int i = a;
        while (i != 0) {
            res += i % 10 + "\n"; 
            i = i / 10; 
        }
        return res;
    }
}