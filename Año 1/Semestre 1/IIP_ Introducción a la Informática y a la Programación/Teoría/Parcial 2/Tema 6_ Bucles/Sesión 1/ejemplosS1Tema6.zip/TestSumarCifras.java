import java.util.Scanner;
import miUtil.ValidarDatos;

/**
 * Clase Programa que lee un entero (int) no negativo valido de 
 * teclado, calcula la suma de sus cifras y la muestra por pantalla
 * 
 * @author Mabel 
 * @version Octubre 2016
 */

public class TestSumarCifras { 
    public static void main(String[] args) {
        
        System.out.println("--- Calculo de la suma de las cifras de a, "
                           + "entero no negativo ---");
        Scanner teclado = new Scanner(System.in);
        
        int a = ValidarDatos.intNoNegativo(teclado); 
        
        System.out.println();
        // Invocacion al metodo sumaCifras
        int sumaCA = sumarCifras(a);
        // Se muestra por pantalla sumaCA
        System.out.println("Suma de las cifras de " + a + " = " + sumaCA);
    } 
   
    // PRECONDICION: a >= 0
    // Devuelve la suma de las cifras de a
    public static int sumarCifras(int a) {
        int res = 0; int i = a; 
        while (i != 0) {
            res = res + i % 10;
            i = i / 10;
        } 
        return res;
    }
}