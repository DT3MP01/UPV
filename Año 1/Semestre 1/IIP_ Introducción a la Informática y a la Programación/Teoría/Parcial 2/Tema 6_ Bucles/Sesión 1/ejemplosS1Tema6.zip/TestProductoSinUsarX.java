import java.util.Scanner;
import miUtil.ValidarDatos;

/**
 * Clase Programa que lee dos enteros (int) no negativos validos de teclado,   
 * calcula su producto mediante sumas sucesivas -usando un bucle while- y lo 
 * muestra por pantalla
 * 
 * @author Mabel 
 * @version Octubre 2016
 */

public class TestProductoSinUsarX {   
    public static void main(String[] args) {
        
        System.out.println("--- Calculo de a * b, enteros no negativos, "
                           + "mediante sumas ---");
        Scanner teclado = new Scanner(System.in);
        
        int a = ValidarDatos.intNoNegativo(teclado);
        int b = ValidarDatos.intNoNegativo(teclado);
        
        // Invocación al metodo productoSinUsarX
        int producto;
        if (a < b) { producto = productoSinUsarX(a, b); }
        else { producto = productoSinUsarX(b, a); }
        // Se muestra por pantalla, para compararlos, producto y a * b
        System.out.printf("%2d  x %2d = %3d (cuando %2d  * %2d = %3d)\n", 
                           a, b, producto, a, b, a * b);
    }
    
    // PRECONDICION: a y b son enteros no negativos
    // Devuelve a * b sin usar *, mediante sumas
    public static int productoSinUsarX(int a, int b) {
        //Iteracion que expresa con un while el calculo a * b mediante sumas 
        int res = 0; int i = 0;
        while (i != a) {
            res = res + b;
            i++;
        }
        return res;
    }
}