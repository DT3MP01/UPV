package miUtil;

import java.util.Scanner;

/**
 * Clase de Utilidades que contiene metodos estaticos para
 * validar datos
 *
 * @author Mabel
 * @version Octubre 2016
 */
public class ValidarDatos {
    
    /** Valida la lectura de un entero POSITIVO desde un teclado, 
     *  i.e. lee un entero de teclado y devuelve un entero positivo */ 
    public static int intPositivo(Scanner teclado) {
        int res;
        do {
            System.out.print("Introduce un entero POSITIVO: "); 
            res = teclado.nextInt(); teclado.nextLine(); 
        
        } while (res <= 0);  
        return res;
    }
    
    /** Valida la lectura de un entero NO NEGATIVO desde un teclado, 
     *  i.e. lee un entero de teclado y devuelve un entero mayor o
     *  igual que cero */ 
    public static int intNoNegativo(Scanner teclado) {
        int res;
        do {
            System.out.print("Introduce un entero NO NEGATIVO: "); 
            res = teclado.nextInt(); teclado.nextLine(); 
        
        } while (res < 0);  
        return res;
    }
}
