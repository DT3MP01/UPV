package sesiones2Y3;

import java.util.Scanner;
import miUtil.ValidarDatos;

/**
 * Clase Programa con Ejercicios No 2 y No 3 TRANSPARENCIAS: 
 * dada la sucesion a_1 = 7 y a_i = a_(i-1) + i para i>1, el programa lee de
 * teclado un valor de n valido (n >= 1) y muestra por pantalla ...
 ** el termino n-esimo de la sucesion, a_n
 ** la suma de los terminos de la sucesion hasta n incluido, 
 ** serie_n (a_1 + ... + a_n)
 *
 * @author IIP 
 * @version Octubre 2016
 */

public class Ej2Y3Transparencias {
    public static void main(String[] args) { 
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Sucesion, " + "\ta_1 = 7\n"
                           + "\ta_i = a_(i-1) + i, i>1\n");
        
        int n = ValidarDatos.intPositivo(teclado);
        
        System.out.print("Termino n de la sucesion, a_n=7 = ");
        //Se invoca al metodo que calcula el termino a_n de la sucesion
        int terminoN = calcularTermino(n);
        System.out.println(terminoN + "\n");
        
        System.out.print("Suma de los n primeros terminos de la sucesion");
        //Se invoca al metodo que calcula el valor de la serie hasta n
        int serieN = calcularSerie(n);
        System.out.println(serieN + "\n");
    }
    
    // Precondicion: n >= 1, garantizada con el filtro de datos del main
    // Estrategia: a_i es el ULTIMO termino calculado
    private static int calcularTermino(int n) {
        int i = 1, res = 7;     // calculado termino a_1
        while (i < n) {
            i++;
            res = res + i;      // calculado termino a_i
        }
        // PARADA:                 calculado termino a_n
        return res;
    }
    
    // Precondicion: n >= 1, garantizada con el filtro de datos del main
    // Estrategia Alternativa: a_i es el SIGUIENTE termino a calcular
    private static int calcularTerminoA(int n) {
        int i = 2, res = 7;     // a calcular termino a_2
        while (i <= n) {
            res = res + i;      // a calcular termino a_(i+1)
            i++;
        }
        // PARADA:                 calculado termino a_n
        return res;
    }
    
    // Precondicion: n >= 1, garantizada con el filtro de datos del main
    public static int calcularSerie(int n) {
        int i = 1, termino = 7, res = 7;   // calculado y sumado termino a_1
        while (i < n) {
            i++;
            termino = termino + i; 
            res = res + termino;         // calculado y sumado termino a_i
        }
        // PARADA:                          calculado y sumado termino a_n
        return res;
    }
}
