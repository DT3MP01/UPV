package sesiones2Y3;

import java.util.Scanner;

/**
 * Ejercicio 9 del Capitulo 8 del libro: programa que, leida de teclado 
 * una palabra (String), escribe en la salida estandar los caracteres 
 * que la componen, usando el metodo charAt de la clase String. 
 * Los caracteres se escribiran en lineas sucesivas, un caracter en cada linea. 
 * Por ejemplo, para "Java", se escribira  J
 *                                         a
 *                                         v
 *                                         a
 * CASO PARTICULAR: si la palabra leida es vacia, no se escribira nada.
 * 
 * NOTA: en un String s no vacío, los caracteres se numeran de 0 a s.length()-1
 *
 * @author IIP 
 * @version Octubre 2016 
 */

public class Ej9Capitulo8Libro {
   
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Dime una palabra: "); 
        String palabra = teclado.nextLine(); 
        //Por que usar nextLine() en vez de next()?
        
        System.out.println("Caracteres de la palabra:");
        int i = 0;
        while (i < palabra.length()) {
            System.out.println(palabra.charAt(i));
            i++;
        }
    }
}