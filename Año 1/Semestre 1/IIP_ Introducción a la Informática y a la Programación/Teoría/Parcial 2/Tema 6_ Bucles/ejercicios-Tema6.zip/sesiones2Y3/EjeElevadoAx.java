package sesiones2Y3;

import java.util.Scanner;
import java.util.Locale;
import miUtil.ValidarDatos;

/** Ejercicio e^x
 *
 *  @author IIP 
 *  @version Octubre 2016
 */

public class EjeElevadoAx {
    public static void main(String[] args) { 

        Scanner teclado = new Scanner(System.in).useLocale(Locale.US);
        
        double x = ValidarDatos.doubleNoNegativo(teclado); // por ejemplo, 3.0
        
        int n = ValidarDatos.intNoNegativo(teclado); // por ejemplo, 10
        
        // Variante 1: calcular como valor de e^x la suma de los 
        // n primeros terminos de la serie 
        double serie = calcularSerie(n, x);
        System.out.printf("Valor aproximado de e^" + x + " = %.16f\n", serie);
        System.out.printf("Valor de Math.exp(" + x + ") = %.16f\n", 
                           Math.exp(x)); 
        System.out.println();
        
        // Variante 2: calcular como valor de e^x la suma de todos aquellos   
        // terminos tales que sean mayores o iguales que un cierto epsilon
        double epsilon; // epsilon, por ejemplo, 1e-11
        do {
            System.out.print("Introduce el error permitido: ");
            epsilon = teclado.nextDouble();
        } while (epsilon < 0.0 || epsilon > 1.0);
        
        serie = calcularSerie(epsilon, x);
        System.out.printf("Valor aproximado de e^" + x + " = %.16f\n", serie);
        System.out.printf("Valor de Math.exp(" + x + ") = %.16f\n", 
                          Math.exp(x)); 
 
    }
    
    // PRECONDICION: x >= 0 AND n >= 0
    public static double calcularSerie(int n, double x) {
        int i = 0; double termino = 1.0, res = termino;
        while (i < n) {
            i++;
            termino = termino * x / i;        
            System.out.printf("Termino %2d de la serie = %.16f\n", i, termino);
            res = res + termino;
        }
        return res;
    }
    
    // PRECONDICION: x >= 0 AND n >= 0 AND  0 <= epsilon < 1.0
    private static double calcularSerie(double epsilon, double x) {
        int i = 0; double termino = 1.0, res = termino; 
        while (termino >= epsilon) {
            i++;
            termino = termino * x / i;
            System.out.printf("Termino %2d de la serie = %.16f\n", i, termino);
            res = res + termino;
        }
        return res;
    }
}
