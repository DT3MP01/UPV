package sesiones2Y3;

import java.util.Scanner;
import miUtil.ValidarDatos;
/**
 * Ejercicio 7 del Capitulo 8 del libro: 
 * calcular a^n siendo a > 0 y n >= 0
 ***a^n = a * a * a * ... * a   si n > 0
 ***a^n = 1                     si n == 0
 *              
 * @author IIP 
 * @version Octubre 2016
 */

public class Ej7Capitulo8Libro {
    
    private static Scanner teclado = new Scanner(System.in);
   
    public static void main(String[] args) {
        
        int a = ValidarDatos.intPositivo(teclado);
        int n = ValidarDatos.intPositivo(teclado);
        
        // Primera version
        int res = 1, // acumula los sucesivos productos
            i = 0;   // indica el numero de productos realizados,
                     // o numero de veces que se ha multiplicado a
        while (i != n) {
            res = res * a;
            i++;
        }
        System.out.println("Version Asc.: " + a + "^" + n + " = " + res); 
           
        // Segunda version
        res = 1; // acumula los sucesivos productos
        i = n;   // indica el numero de productos a realizar,
                 // o numero de veces que falta por multiplicar a            
        while (i != 0) {         
            res = res * a;
            i--;    
        }
        System.out.println("\nVersion Desc.: " + a + "^" + n + " = " + res);
    }
}
