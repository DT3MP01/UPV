package sesiones2Y3;

import java.util.Scanner; 
/**
 * Ejercicio No 5 Transparencias: diseña un programa NPrimerosMultiplosDe 
 * que muestre por pantalla, en lineas separadas, los n primeros multiplos 
 * de x, siendo x y n enteros positivos. Por ejemplo, si x = 9 y n = 4, 
 * se mostraria:
 *     9 x 1 = 9
 *     9 x 2 = 18
 *     9 x 3 = 27
 *     9 x 4 = 36
 *     
 * @author IIP 
 * @version Noviembre 2016
 */
public class Ej5Transparencias {
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        System.out.println("--- Calculo de los n primeros multiplos de x ---");
        
        int x, n; 
        do {
            System.out.print("Introduce x: "); 
            x = teclado.nextInt(); teclado.nextLine();
            System.out.print("Introduce n: "); 
            n = teclado.nextInt(); teclado.nextLine();
        } while (x <= 0 || n <= 0);

        System.out.println("\nCon bucle while:");
        int i = 1; String res = "0\n";
        while (i < n) {
            res = res + x * i + "\n";
            //System.out.printf("%2d x%2d = %4d\n", x, i, x * i); 
            i++;
        }
        System.out.println(res);
        /*
        System.out.println("\nCon bucle do-while:");
        int j = 1;
        do {
            System.out.printf("%2d x %2d = %4d\n", x, j, x * j);
            j++;
        } while (j <= n);
        */   
    }
}
