package sesion4;

import java.util.Scanner;

/** 
 *  Clase programa que dibuja en pantalla figuras 
 *  usando asteriscos ('*') y espacios en blanco (' ')
 *  (ejercicios de las transparencias de la 9 a la 12 de 
 *  la sesion 4)
 *  
 *  @author IIP 
 *  @version Noviembre 2016
 */

public class DibujaFiguras {
    
    /** PRECONDICION: base > 1 AND altura > 1
     *  Dibuja en pantalla un rectangulo de base y altura dadas, con '*'
     */
    public static void rectangulo(int base, int altura) {
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < base; j++) { System.out.print("*"); }
            System.out.println();
        }
    }
    /** PRECONDICION: altura > 1 
     *  Dibuja en pantalla un triangulo rectangulo isosceles 
     *  de altura dada, con '*'
     */
    public static void trianguloRecIsosceles(int base) {
        for (int i = 1; i <= base; i++) {
            for (int j = 1; j <= i; j++) { System.out.print("*"); }
            System.out.println();
        }
    }

    /** PRECONDICION: l > 3 
     *  Dibuja en pantalla el "borde" de un cuadrado de lado l
     */
    public static void bordeDelCuadrado(int l) {
        for (int i = 0; i < l; i++) { System.out.print("*"); }
        System.out.println();
        for (int i = 1; i < l - 1; i++) {
            System.out.print("*");
            for (int j = 1; j < l - 1; j++) { System.out.print(" "); }
            System.out.println("*");
        }
    }
    
    /** PRECONDICION: n > 1 
     *  Dibuja en pantalla una figura con n lineas tal que: 
     *** cada linea tiene n – 1 asteriscos 
     *** el caracter ‘a’ en la posicion diagonal principal de la figura 
     */
    public static void aEnDiagonal(int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < i; j++) { System.out.print("*"); }
            System.out.print('a');
            for (int j = i + 1; j < n; j++) { System.out.print("*"); }
            System.out.println();
        }
    }
    
    /** PRECONDICION: a > 1 
     *  Dibuja en pantalla, con '*', una figura compuesta por un
     *  triangulo rectangulo isosceles de altura a y su imagen especular,
     *  encarados por la hipotenusa y con sus bases separadas por un espacio
     *  en blanco
     */
    public static void enfrentarTriangulos(int a) {
        int b = a * 2 + 1; // base de la figura a dibujar
        for (int i = 1; i <= a; i++) {
            for (int j = 1; j <= i; j++) { System.out.print('*'); }
            int blancos = b - i;
            for (int j = i; j < blancos; j++) { System.out.print(' '); }
            for (int j = 1; j <= i; j++) { System.out.print('*'); }
            System.out.println();
        }
    }
}
