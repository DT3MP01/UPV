package sesion4;

/**
 * Clase Programa que ejecuta el codigo de los ejercicios
 * 3 y 4 del Capitulo 8 del libro de la asignatura. 
 * Comprueba si tus soluciones -ejecutando a mano el codigo-
 * son las mismas; si no lo fueran, identifica tus fallos y
 * corrigelos
 * 
 * @author IIP 
 * @version Noviembre 2016
 */

public class Ej3Y4Capitulo8Libro {
    public static void main(String[] args) {
        
        // Ejercicio 3 del Capitulo 8 del libro: escribir el resultado
        // de ejecutar a mano los siguientes bucles, donde i = 5;
        System.out.println("Ejercicio 3 del Capitulo 9 del libro:");
        int i = 5; 
        while (i >= 0) {             
            System.out.println(i * i); 
            i--;               
        } 
        System.out.println("Termina el bucle 1");
        
        i = 6;
        while (i > 0) {
            i--; 
            System.out.println(i * i);
        }
        System.out.println("Termina el bucle 2");
        
        i = 0;                  
        while (i <= 5) {
            System.out.println(i * i); 
            i++;          
        }   
        System.out.println("Termina el bucle 3");
        
        i = 0;
        while (i <= 5) {
            System.out.println((5 - i) * (5 - i)); 
            i++;
        }
        System.out.println("Termina el bucle 4");
    
        for (i = 5; i >= 0; i--) { System.out.println(i * i); }
        System.out.println("Termina el bucle 5");

        for (i = 0; i <= 5; i++) { System.out.println((5 - i) * (5 - i)); }
        System.out.println("Termina el bucle 6");
        System.out.println("**************************************");    
    
        //Ejercicio 4 del Capitulo 8 del libro: cual es la salida si n=0, 1 y 3
        System.out.println("Ejercicio 4 del Capitulo 9 del libro:");
        int n = 0;  
        for (i = 0; i < n; i++) { n--; }
        System.out.println(i);
        System.out.println();
        
        n = 1;  
        for (i = 0; i < n; i++) { 
            System.out.println("i = " + i + " y n = " + n);  
            n--; 
        }
        System.out.println(i);
        System.out.println();
        n = 3;  
        for (i = 0; i < n; i++) { 
            System.out.println("i = " + i + " y n = " + n);  
            n--; 
        } 
        System.out.println(i);
        System.out.println();
    } 
}
