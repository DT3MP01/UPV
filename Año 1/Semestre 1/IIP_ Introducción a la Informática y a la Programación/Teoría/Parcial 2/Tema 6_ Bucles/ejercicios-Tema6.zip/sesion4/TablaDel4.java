package sesion4;

/**
 * Clase Programa que calcula -usando un bucle for- y muestra 
 * por pantalla la tabla de multiplicar del 4
 * 
 * @author IIP 
 * @version Noviembre 2016
 */

public class TablaDel4 {
    public static void main(String[] args) { 
        
        System.out.println("Tabla del 4");
        
        for (int i = 1; i <= 10; i++) {
            System.out.println("4 x " + i + " = " + 4 * i);
        }
    }
}