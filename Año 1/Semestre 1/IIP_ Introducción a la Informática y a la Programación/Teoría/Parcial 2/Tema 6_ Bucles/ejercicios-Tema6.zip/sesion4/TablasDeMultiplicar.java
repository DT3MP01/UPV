package sesion4;

/**
 * Clase programa que calcula -usando un bucle for anidado- y muestra 
 * por pantalla las tablas de multiplicar, desde la del 1 a la del 10
 * 
 * @author IIP 
 * @version Noviembre 2016
 */

public class TablasDeMultiplicar {
    public static void main(String[] args) { 
        
        System.out.println("**Tablas de multiplicar**\n");
        
        for (int j = 1; j <= 10; j++) {
  
            System.out.printf("Tabla del %2d\n", j);
            for (int i = 1; i <= 10; i++) {
                System.out.printf("%2d x %2d es %2d\n", i, j, i * j);
            }
            
            System.out.println();
        }
    }
}