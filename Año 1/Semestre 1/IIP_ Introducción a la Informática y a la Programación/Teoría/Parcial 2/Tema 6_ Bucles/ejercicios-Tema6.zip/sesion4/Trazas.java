package sesion4;

/**
 * Clase Programa que implementa el ejercicio sobre 
 * bucles anidados de la transparencia 8 de la sesion 4
 * 
 * @author IIP 
 * @version Noviembre 2016
 */
public class Trazas {

    public static void traza1() {
        int nfil = 4, ncol = 3;
        for (int i = 1; i <= nfil; i++) {
            for (int j = 1; j <= ncol; j++) {
                System.out.print(i + "-" + j + "  ");
            }
            System.out.println();
        }
    }


    public static void traza2(int n) {
        for (int i = 0; i <= n; i++) {
            // Sequencia de Z's de longitud i:
            for (int j = 1; j <= i; j++) { System.out.print('Z'); }
            // Sequencia de A's de longitud n:
            for (int j = 1; j <= n; j++) { System.out.print('A'); }
            // Sequencia de Z's de longitud n-i:
            for (int j = 1; j <= n - i; j++) { System.out.print('Z'); }
            System.out.println();
        }
    }
}

  
