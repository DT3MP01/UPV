package sesion1;

/**
 * Clase Programa: test para resolver el ejercicio 1 del Examen 
 * PoliformaT "Actividad Tema 6: Mecanica y Semantica del bucle"
 * 
 * @author IIP 
 * @version Octubre 2016
 */

public class E1ActividadPoliformaT {
    public static void main(String[] args) {
        
        System.out.println("Ejercicio 1: Mostrar por pantalla " 
                           + "los multiplos de 3 en [3, n]");
        System.out.println();
        System.out.println("Valores para n=1. No se deberia mostrar " 
                           + "ningun multiplo, pues 3 > n");
        int n = 1;
        //Bucle de la izquierda (BI):
        System.out.print("BI: ");
        int i = 3;
        while (i <= n) {
            System.out.print(i + " "); 		   
            i = i + 3;
        }
        System.out.println();
        //Bucle de la derecha (BD):
        System.out.print("BD: ");
        i = 0;
        while (i < n) {
            i = i + 3;
            System.out.print(i + " ");
        }
        System.out.println();
        System.out.println();
        
        System.out.println("Valores para n=2. No se deberia mostrar " 
                           + "ningun multiplo, pues 3 > n");
        n = 2;
        //Bucle de la izquierda (BI):
        System.out.print("BI: ");
        i = 3;
        while (i <= n) {
            System.out.print(i + " "); 		   
            i = i + 3;
        }
        System.out.println();
        //Bucle de la derecha (BD):
        System.out.print("BD: ");
        i = 0;
        while (i < n) {
            i = i + 3;
            System.out.print(i + " ");
        }
        System.out.println();
        System.out.println();
        
        System.out.println("Valores para n=3. Se deberia mostrar "
                           + "un unico multiplo, pues 3 = n");
        n = 3;
        //Bucle de la izquierda (BI):
        System.out.print("BI: ");
        i = 3;
        while (i <= n) {
            System.out.print(i + " ");		   
            i = i + 3;
        }
        System.out.println();
        //Bucle de la derecha (BD):
        System.out.print("BD: ");
        i = 0;
        while (i < n) {
            i = i + 3;
            System.out.print(i + " ");
        }
        System.out.println();
        System.out.println();
        
        System.out.println("Valores para n = 4. Se deberia mostrar un "
                           + " unico multiplo, pues entre 3 y 4 solo " 
                           + " hay 1 multiplo de 3");
        n = 4;
        //Bucle de la izquierda (BI):
        System.out.print("BI: ");
        i = 3;
        while (i <= n) {
            System.out.print(i + " ");		   
            i = i + 3;
        }
        System.out.println();
        //Bucle de la derecha (BD):
        System.out.print("BD: ");
        i = 0;
        while (i < n) {
            i = i + 3;
            System.out.print(i + " ");
        }
        System.out.println();
        System.out.println();
        
        System.out.println("Valores para n = 5. Se deberia mostrar un " 
                           + "unico multiplo, pues entre 3 y 4 solo " 
                           + "hay 1 multiplo de 3");
        n = 5;
        //Bucle de la izquierda (BI):
        System.out.print("BI: ");
        i = 3;
        while (i <= n) {
            System.out.print(i + " ");		   
            i = i + 3;
        }
        System.out.println();
        //Bucle de la derecha (BD):
        System.out.print("BD: ");
        i = 0;
        while (i < n) {
            i = i + 3;
            System.out.print(i + " ");
        }
        System.out.println();
        System.out.println();
        
        System.out.println("Valores para n = 6. Se deberian mostrar 2 multiplos" 
                           + ", pues entre 3 y 6 hay 2 multiplos (3+3=6) de 3");
        n = 6;
        //Bucle de la izquierda (BI):
        System.out.print("BI: ");
        i = 3;
        while (i <= n) {
            System.out.print(i + " ");		   
            i = i + 3;
        }
        System.out.println();
        //Bucle de la derecha (BD):
        System.out.print("BD: ");
        i = 0;
        while (i < n) {
            i = i + 3;
            System.out.print(i + " ");
        }
        System.out.println();
        System.out.println();
        System.out.println("Valores para n = 7 Cuantos multiplos se mostraran? " 
                           + "Por que?");
        System.out.println("Que bucle, BI o BD o ambos, los mostrara?"); 
        System.out.println("Cual sera el siguiente valor de n para el que se "
                           + "mostrara un multiplo mas?");
    }
}
