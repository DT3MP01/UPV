package sesion1;

  

import java.util.Scanner;
import miUtil.ValidarDatos;

/**
 * Clase Programa que lee dos enteros (int) no negativos validos de teclado,   
 * calcula su producto mediante sumas sucesivas -usando un bucle while- y lo 
 * muestra por pantalla
 * 
 * @author Mabel 
 * @version Octubre 2016
 */

public class Cuestion1Pag9 {   
    public static void main(String[] args) {
        
        System.out.println("--- Calculo de a * b, enteros no negativos, "
                           + "mediante sumas ---");
        Scanner teclado = new Scanner(System.in);
        
        int a = ValidarDatos.intNoNegativo(teclado);
        int b = ValidarDatos.intNoNegativo(teclado);
        
        // Invocación al metodo productoSinUsarX
        // Invocación al metodo productoSinUsarX
        int producto;
        if (a < b) { producto = productoSinUsarX1(a, b); }
        else { producto = productoSinUsarX1(b, a); }
        // Se muestra por pantalla, para compararlos, producto y a * b
        System.out.printf("%2d  x1 %2d = %3d (cuando %2d  * %2d = %3d)\n", 
                           a, b, producto, a, b, a * b);
    }
    
    // PRECONDICION: a y b son enteros no negativos
    // Devuelve a * b sin usar *, mediante sumas usando
    // la estrategia: Repetir a - 1 veces res = res + b
    //
    // Disenyo "a las bravas" de productoSinUsarX1, i.e. a partir de productoSinUsarX  
    // substituyendo el inicio del bucle por: res = b, i = 1;   
    // PROBLEMA: si a = 0... ¡el bucle es INFINITO!
    //public static int productoSinUsarX1(int a, int b) {
    //    int res = b, i = 1; // Hipotesis: 1 * b = b en repeticion 0
    //    while (i != a) {
    //        res = res + b;
    //        i++;
    //    }
    //    return res;
    //}
    // Metodo correcto, en el que se integra el caso particular a = 0 sin 
    // "destrozar" la estrategia
    public static int productoSinUsarX1(int a, int b) {
        if (a == 0) { return 0; } // Caso especial: a = 0, por lo que el producto es 0
        // else a > 0
        int res = b, i = 1; // Hipotesis: 1 * b = b en repeticion 0
        while (i != a) {
            res = res + b;
            i++;
        }
        return res;
    }
}