package sesion1;

import java.util.Scanner;
import miUtil.ValidarDatos;

/**
 * Clase Programa con el codigo solucion del ejercicio 2
 * del Capitulo 8 del libro de la asignatura, sumar los
 * n primeros naturales con un bucle while
 * 
 * @author IIP 
 * @version Octubre 2016
 */

public class Ejercicio2Capitulo8Libro {
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("--- Suma de los n primeros naturales ---");
        int n = ValidarDatos.intNoNegativo(teclado);
        
        System.out.println();
        // Invocacion al metodo sumarHasta
        int sumaN = sumarHasta(n);
        // Se muestra por pantalla sumaN
        System.out.println("La suma hasta " + n + " es " + sumaN);
    }
    
    // PRECONDICION: n >= 0
    // Estrategia: i es el ultimo numero sumado
    public static int sumarHasta(int n) { 
        int res = 0; int i = 0;  
        while  (i < n) {
            i++;
            res = res + i;
        }
        return res;        
    }
    
    // Estrategia alternativa: i es el siguiente numero a sumar
    /*
    public static int sumarHasta(int n) { 
        int res = 0; int i = 1; 
        while  (i <= n) {
            res = res + i;
            i++;
        }
        return res;        
    }
    */
    
    // Estrategia Descendente: suma de i = n hasta i = 1, pues 0 es el neutro
    // Suma descendente n + (n-1) + (n-2) + ... + 4 + 3 + 2 + 1
    /*
    public static int sumarHasta(int n) {
        int res = 0; int i = n; // i es el siguiente numero a sumar 
        while (i != 0) { // Equivalente a i > 0
          res = res + i;
          i--;
        }
        //PARADA: como el ultimo que se suma es el 1... i == 0
        return res;
    }
    */
}