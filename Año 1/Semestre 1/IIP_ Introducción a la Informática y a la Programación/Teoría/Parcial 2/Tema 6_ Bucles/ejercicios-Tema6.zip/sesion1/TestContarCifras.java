package sesion1;

import java.util.Scanner;
import miUtil.ValidarDatos;
/**
 * Clase Programa que lee un entero (int) no negativo valido de 
 * teclado, calcula su nº de cifras -usando un bucle while- 
 * y lo muestra por pantalla
 * 
 * @author IIP 
 * @version Octubre 2016
 */

public class TestContarCifras {
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("--- Calculo del numero de cifras de a, " 
                           + "entero no negativo ---");
        
        int a = ValidarDatos.intNoNegativo(teclado); 
        
        System.out.println();
        // Invocacion al metodo contarCifras
        int nCA = contarCifras(a);
        // Se muestra por pantalla nCA
        System.out.println("Numero de cifras de " + a + " = " + nCA);
    } 
   
    // Disenyo "a las bravas" de contarCifras, i.e. a partir de sumarCifras  
    // substituyendo "sumar cifra" por "contar cifra" --> El resultado es  
    // incorrecto para a = 0, pues devuelve 0 como nº de cifras de a. Si para 
    // "arreglarlo", se cambia la guarda del bucle por i >= 0, se tiene un 
    // bucle infinito 
    //public static int contarCifras(int a) {
    //    int res = 0, i = a;
    //    while (i >= 0) {
    //        res++;
    //        i = i / 10;
    //    }
    //    return res;
    //}
   
    // Metodo correcto, en el que se integra el caso particular a = 0 sin 
    // "destrozar" la estrategia
    public static int contarCifras(int a) {
        if (a == 0) { return 1; } // Caso especial: a = 0 tiene 1 cifra
        //else a > 0
        int res = 0, i = a; 
        while (i > 0) { 
            res++;
            i = i / 10;    
        }
        return res;
    }
}