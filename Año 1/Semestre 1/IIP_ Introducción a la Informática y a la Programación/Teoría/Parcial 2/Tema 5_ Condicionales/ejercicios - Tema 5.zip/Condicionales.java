/**
 * Clase de Utilidades
 * 
 * @author IIP 
 * @version Octubre 2018
 */

public class Condicionales {

    /**
     * Ejercicio 3 del libro: en una tienda de electrodomesticos se aplican 
     * distintos descuentos en funcion del total de compras realizadas:
     * (a) Si total < 500 euros, no se aplica descuento
     * (b) Si 500 euros <= total <= 2000 euros, se aplica un descuento del 30%
     * (c) Si total > 2000 euros, se aplica un descuento del 50%
     * Escribe un método que, dado un total, devuelva la cantidad a pagar tras 
     * aplicar el descuento correspondiente. Se debe resolver el problema con 
     * una sola instruccion condicional (anidada) 
     * @param total double
     * @return double
     */
    public static double ejercicio3(double total) {
        
        double res = total; //hipotesis: no se aplica descuento
        // version 1: empezando por if (total >= 500)
        if (total >= 500) {					
            /*COMPLETAR*/
        }
        // version 2: empezando por if (total <= 2000)
        /*if (total <= 2000) { 
         *    //COMPLETAR
         *}*/
        return res;
    }
    
    /**
     * Ejercicio 4 del libro: reescribe el codigo que figura comentado 
     * a continuacion para que, haciendo exactamente lo mismo, sea mas 
     * eficiente. Para ello debes usar una sola instruccion condicional 
     * (anidada) if (x < 0) ... else ...
     * 
     * Devuelve un String con un mensaje que depende de los valores de x y c.
     * @param x int
     * @param c char
     * @return String
     */
    public static String ejercicio4(int x, char c) {
        String res = "";
        // Codigo a reescribir: en el Mejor de los Casos (x < 0 AND 
        // c == 'x'), hace 2 preguntas para establecer el resultado; 
        // en el Peor de los Casos (x > 0  AND c != y) hace 8 preguntas 
        // (considerando x >=0 dos preguntas)
        /*if (x < 0 && c == 'x') { res = "Caso 1"; }
        else if (x < 0 && c != 'x') { res = "Caso 2"; }
        else if (x >= 0 && c == 'y') { res = "Caso 3"; }
        else if (x >= 0 && c != 'y') { res = "Caso 4"; }*/
        
        // Rescribe de forma eficiente el codigo con la siguiente  
        // estructura, asegurando que hace lo mismo
        if (x < 0) {
            
        }
        else {
         
        }
        
        return res;
    }
    
    /**
     * Ejercicio 11 del libro: dados 3 enteros a, b y c, implementa 
     * distintas soluciones para el siguiente analisis por casos,  
     * haciendo uso de operadores cortcircuitados y condicionales if
     *      a > b -> true
     *      a < b -> false
     *      a == b y a > c -> true
     *      a == b y a < c -> false
     *      a == b y a == c -> false
     * 
     * @param a int, primer entero
     * @param b int, segundo entero
     * @param c int, tercer entero
     * @return boolean, resultado 
     */
    public static boolean ejercicio11(int a, int b, int c) {
        boolean res;
        // Primera version: saca "factor comun" los casos
        // en los que el resultado es true y expresalo con un
        // if...else simple
        
        /*COMPLETAR*/
        
       // Segunda version: toma como hipotesis res = false,
        // por lo que se elimina el else de la primera version
        
        /*COMPLETAR*/
        
        // Tercera version - sin if: asigna a res el valor  
        // de una expresion booleana
        
        /*COMPLETAR*/
        
        return res;
    }
    
    /**
     * Ejercicio 22 del libro: metodo que dados 2 enteros, num1 y num2, 
     * devuelve true si su producto es positivo o nulo y false en caso
     * contrario (producto negativo). 
     * Para establecer el resultado NO debes calcular el producto
     * 
     * @param num1 int
     * @param num2 int
     * @return boolean, res 
     */
    public static boolean ejercicio22(int num1, int num2) {
        boolean res = true; // hipotesis: producto positivo o nulo
        // COMPLETAR
        return res;
    }
} 

