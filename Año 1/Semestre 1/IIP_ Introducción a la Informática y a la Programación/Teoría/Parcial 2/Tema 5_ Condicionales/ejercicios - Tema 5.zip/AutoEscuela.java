import java.util.Scanner;

/**
 * Clase AutoEscuela: Calcula la tarifa de una autoescuela teniendo en cuenta
 * el tipo de carnet (A, B, C, D) y el numero de practicas realizadas
 * Precios de matriculas (en euros): A 150, B 325, C 520, D 610 
 * Precios por practica segun carnet (en euros): A 15, B 21, C 36, D 50
 * 
 * @author IIP 
 * @version Curs 2016-17
 */

public class AutoEscuela {
    
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        System.out.print("Tipo de carnet? (A, B, C o D) "); 
        char carnet = teclado.next().charAt(0);
        // char carnet = teclado.next("\\S").charAt(0); 
        // la lectura de carnet puede hacerse como sigue:
        // carnet = teclado.next("\\S").toUpperCase().charAt(0);
        // Asi, la letra estara en mayuscula y se pueden eliminar
        // los case 'minuscula' del switch
        System.out.print("Numero de practicas realizadas? "); 
        int pract = teclado.nextInt(); 
        int precio = 0; 
        
        // COMPLETAR con un switch
    }
}
