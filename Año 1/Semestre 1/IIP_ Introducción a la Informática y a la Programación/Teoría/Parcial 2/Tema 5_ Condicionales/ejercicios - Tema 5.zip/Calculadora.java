import java.util.Scanner;
import java.util.Locale;
/**
 * Clase Calculadora: simula una calculadora, considerando que los
 * calculos posibles son del tipo num1 operador num2, donde num1 y num2
 * son dos numeros reales cualesquira y operador es  +, -, *, / 
 * El programa pedira al usuario en primer lugar el valor num1, a
 * continuacion el operador y finalmente el valor num2
 * 
 * @author IIP
 * @version Curso 2016/17
 */

public class Calculadora {
    
    public static void main(String[] args) {   
        Scanner tec = new Scanner(System.in).useLocale(Locale.US);
        System.out.print("num1? ");
        double num1 = tec.nextDouble();
        System.out.print("operador? ");
        char op = tec.next("\\S").charAt(0);
        System.out.print("num2? ");
        double num2 = tec.nextDouble();
        
        double result = 0.0; //para guardar el resultado de la operacion
        boolean error = false; // para indicar si hay error
        
        // COMPLETAR con un switch
        
        if (error) { System.out.println("Error"); }
        else { System.out.println("El resultado es: " + result); } 
    }
}