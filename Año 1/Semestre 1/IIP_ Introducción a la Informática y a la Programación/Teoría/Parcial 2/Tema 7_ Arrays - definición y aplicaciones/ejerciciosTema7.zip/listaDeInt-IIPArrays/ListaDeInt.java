package listaDeInt-IIPArrays;

/**
 * Clase ListaDeInt: representa una lista de, como maximo, 100 numeros
 * de tipo entero. Nota que, a partir de su creacion, el numero de 
 * elementos -la talla- de la lista varia entre 0 y 100 <br><br>
 * 
 * IMPORTANTE: una lista puede tener elementos repetidos
 */

public class ListaDeInt {
   
    /** Valor int del numero de elementos maximo de una lista */
    /*COMPLETAR*/ C_P_D = 100;
    
    // Una lista TIENE, uno tras otro, en secuencia, numeros enteros, 
    // C_P_D como maximo
    /*COMPLETAR*/ elArray; 
    
    // Una lista TIENE UN numero de elementos en un momento dado, i.e. una
    // talla que varia entre 0 (lista vacia) y C_P_D (lista llena); esta
    // talla coincide con la posicion de la primera componente libre de elArray
    /*COMPLETAR*/ talla

    /** SII 0 <= n <= 100: 
     *  crea una lista con n elementos enteros, con 
     *  valores generados aleatoriamente en el intervalo [0, 10 * talla] */ 
    public ListaDeInt(int n) {
        /*COMPLETAR*/;            // inicializacion del atributo elArray, con C_P_D 
                                  // posiciones contiguas de memoria inicializadas a 0,
                                  // valor por defecto de un int
                                  
        /*COMPLETAR*/             // inicializacion del atributo talla a n

        /*COMPLETAR*/             // inicializacion de las talla componentes de elArray                       
                                  // a valores aleatorios el intervalo [0, 10 * talla]
                      
    }
    
    /** Crea una lista de enteros vacia, con 0 elementos */ 
    public ListaDeInt() { 
        /*COMPLETAR*/ 
    }
    
    /** Devuelve la talla de una lista de enteros */
    public int talla() { /*COMPLETAR*/ }
    
    /** Comprueba si una lista de enteros esta vacia */
    public boolean esVacia() { /*COMPLETAR*/ }
    
    /** SII 0 <= i < talla(): 
     *  devuelve el entero en posicion i en una lista */
    public int get(int i) { /*COMPLETAR*/ }
    
    /** Inserta x en una lista, devolviendo true para indicarlo; 
     *  si NO se ha podido realizar la insercion porque la lista 
     *  ya esta llena devuelve false para advertirlo */
    public boolean insertar(int x) {
        boolean cabe = true;
        /*COMPLETAR*/
        return cabe;
    }
    
    /** SII 0 <= i < talla(): 
     *  Borrado "lazy" del elemento en posicion i de una lista de enteros */
    // Nota que con la precondicion exigida NO hay que analizar 
    // el caso de lista vacia en el codigo
    public void borrar(int i) {
        /*COMPLETAR*/
    }
    
    /** Devuelve la suma de los elementos de una lista de enteros */
    public int sumar() {
        int res = 0;
        /*COMPLETAR*/
        return res;
    }
    
    /** SII talla() > 0
     *  Devuelve la media de los elementos de una lista de enteros */
    // En el codigo de este metodo debes invocar al metodo sumar()
    public double media() {
        /*COMPLETAR*/
    }
    
    /** Devuelve el numero de veces que aparece x, o frecuencia de x,  
     *  en una lista de enteros */
    public int frecuencia(int x) {
        /*COMPLETAR*/
    }
    
    /** Devuelve un String con los talla() elementos de una lista de 
     *  enteros en un cierto formato. Por ejemplo, si los datos de 
     *  la lista son 1, 5 y 7, el resultado es el String "[1, 5, 7]"; 
     *  pero si la lista esta vacia, es el String "[]"
     */
    public String toString() {
        /*COMPLETAR*/
    }
    
    /** SII talla() > 0
     *  Devuelve el (primer) maximo de una lista de enteros */
    /*COMPLETAR*/maximo/*COMPLETAR*/{
        /*COMPLETAR*/
    }
    
    /** SII talla() > 0
     *  Devuelve el (primer) minimo de una lista de enteros */
    /*COMPLETAR*/minimo/*COMPLETAR*/{
        /*COMPLETAR*/
    }
    
    /** SII talla() > 0
     *  Devuelve la posicion del (primer) minimo de una lista de enteros */
    /*COMPLETAR*/posMminimo/*COMPLETAR*/{
        /*COMPLETAR*/
    }
}