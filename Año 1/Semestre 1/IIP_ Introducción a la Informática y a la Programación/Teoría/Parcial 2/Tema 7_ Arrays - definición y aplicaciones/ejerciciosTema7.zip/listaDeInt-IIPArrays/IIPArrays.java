package listaDeInt-IIPArrays; 

/**
 * Clase de Utilidades IIPArrays: libreria de metodos estaticos
 * sobre arrays de cualquier tipo base <br><br>
 * 
 * IMPORTANTE: salvo que se indique lo contrario, el array que   
 *             se pasa como parametro tiene ocupadas todas sus 
 *             posiciones y puede contener elementos repetidos           
 */

public class IIPArrays {

    /** SII v.length > 0: devuelve el (primer) minimo de v */
    public static int minimo(double[] v) {
        /*COMPLETAR*/
    }
    
    /** SII v.length > 0: devuelve la posicion del (primer) 
     *  minimo de v */
    public static int posMinimo(double[] v) {
        /*COMPLETAR*/
    }
    
    /** SII v.length > 0: obtiene el (primer) maximo de v */
    public static int maximo(double[] v) {
        /*COMPLETAR*/
    }
    
    /** Devuelve un String con los datos de v en el formato del 
     *  siguiente ejemplo: si los datos de v son 1, 5 y 7 en el 
     *  orden ascendente, entonces el resultado del metodo sera
     *  [1, 5, 7]; en el caso en que v esta vacio, devuelve [] */
    public static String toString(int[] v) {
        /*COMPLETAR*/
    }
    
    /** Devuelve la suma de los elementos de v, un array de int */
    /*COMPLETAR*/ sumar(/*COMPLETAR*/) {
        /*COMPLETAR*/
    }
    
    /** SII v.length>0: devuelve la media de los elementos de v, 
     *  un array de int */
    // En el codigo de este metodo debes invocar al metodo sumar()
    /*COMPLETAR*/ media /*COMPLETAR*/ { 
        /*COMPLETAR*/
    }
    
    /** Devuelve el numero de veces que aparece x en v, un
     *  array de int  */
    /*COMPLETAR*/ frecuencia/*COMPLETAR*/ {
        /*COMPLETAR*/
    }
}
