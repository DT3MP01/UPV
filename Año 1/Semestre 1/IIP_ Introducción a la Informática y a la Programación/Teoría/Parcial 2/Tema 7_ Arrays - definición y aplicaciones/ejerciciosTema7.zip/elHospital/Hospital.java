package elHospital;

/**
 * Clase Hospital: representa un hospital mediante un array de,  
 * como maximo, C_P_D camas ocupadas por, como maximo, C_P_D 
 * Pacientes <br><br> 
 * 
 * IMPORTANTE: excepto la 0, cada posicion {@code i} del array 
 * ({@code 1<=i<=C_P_D}) representa un numero de cama, mientras 
 * que su correspondiente componente representa al paciente que 
 * la ocupa
 * 
 * @author IIP
 * @version Noviembre 2016
 */

public class Hospital {
    
    // Un hospital TIENE UN numero maximo de camas dado:
    /** 
     * Valor ({@code int}) que indica el numero maximo de camas 
     * de un hospital, o maximo de pacientes ingresados en el
     */
    /*COMPLETAR*/ elArray; /*COMPLETAR*/ C_P_D = 200;
     
    // Un hospital tiene un numero de camas libres en un momento dado, 
    // entre 1 y C_P_D. Nota que el numero de camas ocupadas, o de pacientes, 
    // del hospital es C_P_D - libres
    /*COMPLETAR*/ libres;
    
    /**
     * Crea un hospital vacio, con todas sus {@code C_P_D} camas libres 
     */
    public Hospital() {
        // Como cada posicion de elArray EXCEPTO la 0 representa 
        // un numero de cama, elArray tiene C_P_D + 1 componentes
        /*COMPLETAR*/
    } 
    
    /**
     * Devuelve el numero de camas libres de un hospital
     * 
     * @return el numero ({@code int}) de camas libres
     */
    public int getLibres() { /*COMPLETAR*/ }

    /**
     * Comprueba si hay camas libres en un hospital
     * 
     * @return el valor {@code boolean} resultado de la comprobacion
     */
    public boolean hayLibres() { /*COMPLETAR*/ }
    
    /**
     * PRECONDICION: {@code 1 <= i <= C_P_D}
     * comprueba si la cama {@code i} de un hospital esta ocupada
     * 
     * @param i  un numero ({@code int}) de cama valido
     * @return el valor {@code boolean} que indica si {@code i} esta ocupada
     */
    public boolean estaOcupada(int i) { /*COMPLETAR*/ }
    
    /**
     * PRECONDICION: {@code 1 <= i <= C_P_D} 
     *               AND paciente de la cama {@code i} sano
     * da el alta al paciente de la cama {@code i}, que queda libre (eliminar)
     * 
     * @param i  un numero ({@code int}) de cama valido
     */
    private void darAltaPaciente(int i) {
        /*COMPLETAR*/
    } 
    
    /**
     * Devuelve la posicion de la primera cama libre de un hospital, 
     * o numero de la primera cama libre; si NO hay camas libres 
     * devuelve 0 para advertirlo
     * 
     * @return la posicion {@code int} de la 1era cama libre, 0 si no hay
     */
    // Usa -invoca- el metodo hayLibres en el codigo de este metodo...
    // EL MENOR NUMERO DE VECES POSIBLE
    public int primeraLibre() {
           /*COMPLETAR*/
    }

    /**
     * PRECONDICION: {@code hayLibres()}
     * ingresa al paciente {@code p} en la primera cama libre de un hospital
     * (insercion)
     * 
     * @param  p un paciente ({@code Paciente}) a ingresar
     */
    // Usa -invoca- el metodo primeraLibre en el codigo de este metodo...
    // EL MENOR NUMERO DE VECES POSIBLE
    public void ingresar(Paciente p) {
        /*COMPLETAR*/
    } 
    
    /**
     * Trata a todos los pacientes del hospital y da el alta medica 
     * a aquellos que, tras dicho tratamiento, sanan (su estado de 
     * gravedad es {@code SANO} tras tratarlos)
     */
    // Usa -invoca- en su codigo el metodo tratamiento() de la clase  
    // Paciente y el metodo darAltaPaciente de esta clase... 
    // EL MENOR NUMERO DE VECES POSIBLE
    public void darAltas() {
        /*COMPLETAR*/
    } 

    /**
     * Devuelve un {@code String} que representa un hospital, i.e. los 
     * pacientes que ocupan sus camas y que camas estan libres; si el 
     * hospital esta vacio se advierte con el mensaje correspondiente <br><br>
     * 
     * Por ejemplo: si {@code C_P_D} = 4, el hospital NO esta vacio y 
     * el separador de numero de cama y paciente es un tabulador, el 
     * resultado del metodo es:<br>
     *  "1  Maria Medina Mu?oz, paciente de 30 a?os en estado leve 
     *   2  Pepe Perez Santarosa, paciente de 46 a?os en estado grave 
     *   3  libre
     *   4  Juan Lopez Ayala, paciente de 50 a?os en estado moderado
     *   " <br>
     * Pero si el hospital esta vacio, siendo {@code C_P_D} = 4, 
     * el resultado es: <br>
     * "No hay pacientes en el hospital: sus 4 camas estan libres." <br><br>
     * 
     * Sobrescribe el metodo {@code toString} de {@code Object}
     * 
     * @return el literal de {@code String} que describe un hospital  
     * para los casos y con los formatos indicados en el ejemplo
     */
    public String toString() {
        /*COMPLETAR*/
    }
}
