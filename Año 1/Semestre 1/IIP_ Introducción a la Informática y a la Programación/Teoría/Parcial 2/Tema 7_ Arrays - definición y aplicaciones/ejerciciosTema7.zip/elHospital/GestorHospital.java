package elHospital;

import java.util.Scanner;

/**
 * Programa GestorHospital: lanza la aplicacion que simula el funcionamiento de
 * un hospital, presentando al usuario en modo texto una interfaz basica con la
 * que este puede crear y manipular un hospital de, como maximo, C_P_D camas. 
 * Por ello, su unico metodo publico es un main en el se describen, via menu, 
 * las opciones de trabajo que permite la aplicacion 
 */ 

public class GestorHospital {
    
    private static int menu(Scanner teclado) {
        int opcion;
        do {
            System.out.println("\n********* HOSPITAL **********");
            System.out.println(" 1. Ingresos");
            System.out.println(" 2. Altas");
            System.out.println(" 3. Ver hospital");
            System.out.println(" 0. Terminar");
            System.out.println("*****************************");
            System.out.print("Elige una opcion: ");
            opcion = teclado.nextInt();
            teclado.nextLine();
            if (opcion < 0 || opcion > 3) { 
                System.out.println("\nOpcion incorrecta.\n"); 
            }
        } while (opcion < 0 || opcion > 3);
        return opcion;
    }
    
    public static void main(String[] args) {
        
        Hospital h = new Hospital();
        
        Scanner teclado = new Scanner(System.in);
        int opcion;
        do {
            opcion = menu(teclado);
            switch(opcion) {
                case 1: // Ingresos
                    if (!h.hayLibres()) { 
                        System.out.println("Stop ingreso: no quedan camas");
                    }
                    else { 
                        System.out.println("\nDatos del Paciente a ingresar:");
                        System.out.print("\tNombre y apellidos? ");
                        String n = teclado.nextLine().trim();
                        int e;
                        do {
                            System.out.print("\tEdad? ");
                            e = teclado.nextInt();
                            teclado.nextLine();
                        } while (e < 0);
                        //Ingresar paciente de nombre n y edad e
                        Paciente p = new Paciente(n, e); 
                        h.ingresar(p); 
                    }
                    break;
                case 2: // Altas
                    h.darAltas();
                    break;
                case 3: // Mostrar el hospital por pantalla
                    System.out.println("\n" + h.toString());
                    break;
                default: // Terminar
                    System.out.println("\n*** Acabando sesion de trabajo ***");
            }
        } while (opcion != 0);
    }
}
