package elHospital;

/**
 * Clase Paciente: representa un paciente de un hospital, que TIENE   
 * un nombre, una edad y un estado de gravedad (de grave a leve 
 * pasando por moderado) <br><br>
 * 
 * IMPORTANTE: al sufrir un tratamiento, sI o sI, un paciente mejora 
 * su estado. Por ejemplo, TRAS tratar a un paciente en estado leve, 
 * su estado pasa a ser sano
 * 
 * @author IIP
 * @version Noviembre 2016
 */
public class Paciente {
    
    // Un paciente TIENE UN estado de gravedad ...
    /** 
     * Codigo ({@code int}) para el estado grave de un paciente
     */
    public static final int GRAVE = 1;
    /** 
     * Codigo ({@code int}) para el estado moderado de un paciente
     */
    public static final int MODERADO = 2;
    /** 
     * Codigo ({@code int}) para el estado leve de un paciente
     */
    public static final int LEVE = 3;
    /** 
     * Codigo ({@code int}) para el estado sano de un paciente
     */
    public static final int SANO = 4;
    
    // Un paciente TIENE UN ...
    private String nombre;
    private int edad, estado;
    
    /**
     * Crea un paciente de nombre {@code n}, de edad {@code e} y  
     * le asigna un estado aleatorio en el intervalo [GRAVE, LEVE]
     * 
     * @param n  un {@code String} 
     * @param e  un {@code int} 
     */
    public Paciente(String n, int e) {
        nombre = n;
        edad = e;
        estado = (int) (Math.random() * (LEVE - GRAVE + 1) + GRAVE);
    }
    
    /**
     * Devuelve la edad de un paciente
     * 
     * @return el valor {@code int} de la edad de un paciente
     */
    public int getEdad() { return edad; }
    
    /**
     * Devuelve el estado de un paciente.
     * 
     * @return el valor {@code int} del estado de un paciente
     */
    public int getEstado() { return estado; } 
    
    /**
     * Incrementa en uno el estado de un paciente
     */
    public void tratamiento() { estado++; }
    
    /**
     * Devuelve un String que representa un paciente, i.e. sus componentes
     * en un formato dado
     * 
     * @return el literal {@code String} con los datos de un paciente
     */
    public String toString() { 
        String estadoInteligible = "";
        switch (estado) {
            case GRAVE: 
                estadoInteligible = "grave"; break;
            case MODERADO: 
                estadoInteligible = "moderado"; break;
            case LEVE: 
                estadoInteligible = "leve"; break;
            case SANO: 
                estadoInteligible = "sano"; break;
            default: 
                estadoInteligible = "ERROR: " + estado 
                                    + " de gravedad DESconocido";
        }
        return String.format("%25s, paciente de %2d a?os en estado %-8s", 
                             nombre, edad, estadoInteligible); 
    }
}