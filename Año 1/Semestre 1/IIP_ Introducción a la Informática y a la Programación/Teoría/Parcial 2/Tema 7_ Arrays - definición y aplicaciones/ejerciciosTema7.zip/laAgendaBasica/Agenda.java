package laAgendaBasica;

/**
 * Clase Agenda: representa una agenda telefonica como una lista de, 
 * como maximo, 250 contactos. Nota que, a partir de su creacion, el  
 * numero de contactos -la talla- de una agenda varia entre 0 y 250 <br><br> 
 * 
 * IMPORTANTE 1: una agenda, por definicion, NO tiene contactos repetidos <br>
 * 
 * IMPORTANTE 2: recuerda que para acceder a un telefono de la agenda es 
 * imprescindible buscar primero el nombre a el asociado. Por tanto, ...<br>
 *** (a) Los nombres de los contactos son las CLAVES de acceso a la informacion 
 ***     (telefonos) que contiene una agenda <br>
 * 
 *** (b) Para insertar/actualizar, consultar y eliminar un contacto de una 
 ***     agenda, PRIMERO hay que buscar el nombre del contacto <br><br>
 *
 ** En resumen: porque la operacion kernel es la busqueda POR NOMBRE O CLAVE, 
 ** una agenda no es mas que un tipo particular de Diccionario cuyas entradas 
 ** son sus contactos
 *
 * @author IIP
 * @version Noviembre 2017
 */

public class Agenda {

    // Una agenda TIENE UN (cierto) numero maximo de contactos:
    /** 
     * Valor ({@code int}) del numero de contactos maximo de una agenda
     */
    /*COMPLETAR*/ C_P_D = 250;
 
    // Una agenda TIENE UNA lista de contactos, como maximo C_P_D
    /*COMPLETAR*/ elArray; 
    // Una agenda TIENE UN numero de contactos en un momento dado, i.e. una
    // talla que varia entre 0 (agenda vacia) y C_P_D (agenda llena); esta
    // talla coincide con la posicion de la primera componente libre de elArray
    /*COMPLETAR*/ talla;

    /**
     * Crea una agenda vacia, con 0 contactos
     */
    public Agenda() {
        /*COMPLETAR*/
    }

    /**
     * Devuelve la talla de una agenda, i.e. el numero de contactos  
     * que contiene en un momento dado (a partir de su creacion)
     * 
     * @return el numero ({@code int}) de contactos, o talla, de una agenda
     */
    public int talla() { /*COMPLETAR*/ }
    
    // Metodo auxiliar de busqueda del nombre de un contacto, IMPRESCINDIBLE  
    // para realizar cualquier operacion de la agenda: insertar, eliminar y 
    // consultar (recuperar): devuelve la posicion de un contacto de nombre 
    // dado en elrray[0, talla[; si dicho contacto no existe devuelve -1 
    // para advertirlo
    private int buscar(String n) {
        /*COMPLETAR*/     
    }
    
    /**
     * Inserta el contacto -valido- {@code nuevo} en una agenda, o lo   
     * actualiza si ya existe un contacto con el mismo nombre, Y devuelve 
     * {@code true} para indicarlo; si NO se ha podido realizar la insercion, 
     * por estar llena la agenda, devuelve {@code false} para advertirlo  
     * 
     * @param nuevo  un {@code Contacto} valido
     * @return el {@code boolean} que indica si se ha insertado {@code nuevo}
     */
    // Usa -invoca- el metodo buscar en el codigo de este metodo...
    // EL MENOR NUMERO DE VECES POSIBLE
    public boolean insertar(Contacto nuevo) {
        boolean cabe = true;
        // Busqueda de nuevo, un contacto en elrray[0, talla[: 
        // si existe un contacto **con el mismo nombre** se reemplaza  
        // por nuevo, i.e. se actualiza el contacto; sino, SII cabe, se  
        // inserta el nuevo contacto detras del ultimo existente, en 
        // la posicion talla de elArray
        int posCAInsertar = /*COMPLETAR*/;
        /*COMPLETAR*/
        return cabe;
    }
    
    /**
     * Devuelve -recupera- el telefono asociado al contacto de nombre  
     * {@code n} -valido- de una agenda; si no existe tal contacto,  
     * devuelve {@code null} para advertirlo
     * 
     * @param n  un nombre ({@code String}) valido de contacto
     * @return el telefono ({@code String}) asociado a {@code n}
     */
    // Usa -invoca- el metodo buscar en el codigo de este metodo...
    // EL MENOR NUMERO DE VECES POSIBLE
    public String recuperar(String n) {
        String telefono = null;
        // Busqueda de n, el nombre de un contacto, en elrray[0..talla[: 
        // si existe, se devuelve el telefono asociado como resultado;  
        // si no existe un contacto con tal nombre, devuelve null
        int posCARecuperar = /*COMPLETAR*/;
        /*COMPLETAR*/
        return telefono;
    }
    
    /**
     * Elimina el contacto de nombre {@code n} -valido- de una agenda Y 
     * devuelve {@code true} para indicarlo; si NO se ha podido borrar, 
     * por no existir el contacto de nombre {@code n} en la agenda, devuelve 
     * {@code false} para advertirlo
     * 
     * @param n  un nombre ({@code String}) valido de contacto
     * @return el {@code boolean} que indica si se ha eliminado el contacto de 
     * nombre {@code n}
     */
    // Usa -invoca- el metodo buscar en el codigo de este metodo...
    // EL MENOR NUMERO DE VECES POSIBLE
    public boolean eliminar(String n) {      
        boolean esta = true;
        // Busqueda de n, el nombre de un contacto, en elrray[0, talla[: 
        // Si existe un contacto con nombre n lo borra y devuelve true; 
        // para borrarlo, como la agenda NO esta ordenada, reemplaza 
        // ese contacto por el que hay en talla - 1 (el ultimo de la agenda)
        // y actualiza talla (borrado "lazy")
        // Si no existe un contacto con nombre n en la agenda, devuelve false 
        int posCAEliminar = /*COMPLETAR*/;
        /* COMPLETAR */
        return esta;
    }
    
    /**
     * Devuelve un {@code String} que representa una agenda, i.e. los 
     * nombres y telefonos de sus contactos con cierto formato; si la
     * agenda esta vacia se advierte con el mensaje correspondiente
     * 
     ** Sobrescribe el metodo {@code toString} de {@code Object}
     * * 
     * @return el literal de {@code String} que contiene, en cierto formato, 
     * los contactos de una agenda ... ??En orden alfabetico??
     */
    public String toString() {
        if (talla == 0) { return "Agenda vacia, con 0 Contactos"; } 
        String res = "====================\n";
        for (int i = 0; i < talla; i++) {
            res += elArray[i] + "\n====================\n";
        }
        return res;
    }
}
