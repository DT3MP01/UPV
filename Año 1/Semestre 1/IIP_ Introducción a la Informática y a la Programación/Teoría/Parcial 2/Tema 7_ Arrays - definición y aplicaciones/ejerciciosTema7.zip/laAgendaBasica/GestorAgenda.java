package laAgendaBasica;

import java.util.Scanner;

/**
 * Programa GestorAgenda: lanza la aplicacion de simulacion  
 * de una agenda telefonica, presentando al usario en modo   
 * texto una interfaz basica con la que este puede crear y
 * manipular una agenda de, como maximo, C_P_D contactos. 
 * Por ello, su unico metodo publico es un main en el se 
 * describen via menu las opciones de trabajo que permite 
 * la aplicacion
 * 
 *
 * @author IIP
 * @version Noviembre 2016
 */

public class GestorAgenda {
    public static void main(String[] args) {
        
        Agenda miAgenda = new Agenda();
        
        Scanner teclado = new Scanner(System.in);
        int opcion = 0;
        do {
            opcion = menu(teclado);
            switch (opcion) {
                case 1: 
                    System.out.println(miAgenda.toString()); break;
                case 2: 
                    insertarContacto(miAgenda, teclado); break;
                case 3: 
                    recuperarTelefono(miAgenda, teclado); break;
                case 4: 
                    eliminarContacto(miAgenda, teclado); break;
                case 0: 
                    System.out.println("Cerrando Agenda."); break;
                default:
            }
        } while (opcion != 0);        
    }
    
    private static int menu(Scanner teclado) {
        int opcion;
        do {
            System.out.println("\n            Menu ");
            System.out.println("--------------------------------------------");
            System.out.println("| 1.- Mostrar contactos                    |");
            System.out.println("| 2.- A?adir/Actualizar un contacto        |");
            System.out.println("| 3.- Consultar el telefono de un contacto |");
            System.out.println("| 4.- Eliminar un contacto                 |");
            System.out.println("| 0.- Cerrar la agenda                     |");
            System.out.println("--------------------------------------------");
            System.out.print("Elige una opcion [0..4]: ");
            opcion = teclado.nextInt(); teclado.nextLine();
        } while (opcion < 0 || opcion > 4);
        return opcion;        
    }
    
    private static void insertarContacto(Agenda miAgenda, Scanner teclado) {
        String nombre, telefono;
        // 1.-Filtro de datos al leer el nombre del contacto: un nombre valido 
        //    para un contacto de miAgenda puede estar compuesto por cualquier 
        //    caracter PERO DEBE tener una longitud en el intervalo [1, 40]
        do {
            System.out.print("Introduce el nombre del contacto, minimo una "
                             + "letra y maximo 40: "); 
            nombre = teclado.nextLine();
        } while (nombre.length() < 1 || nombre.length() > 40);
        
        // 2.-Filtro de datos al leer el telefono de un contacto: un telefono 
        //    valido para un contacto de miAgenda DEBE estar compuesto por 9  
        //    caracteres del intervalo ['0', '9'], PERO el primero de ellos  
        //    NO puede ser '0'
        do { 
            System.out.print("Introduce el telefono del contacto: "); 
            telefono = teclado.nextLine();
        } while (!telefono.matches("[0-9]+") 
                || telefono.length() != 9 || telefono.charAt(0) == '0');
        
        // 3.-Filtro de datos antes de crear el nuevo contacto a insertar: 
        //    la forma de escribir un nombre, con/sin mayusculas o con/sin 
        //    blancos delante o detras, NO puede dar lugar a contactos 
        //    repetidos. Por ello, en miAgenda todos los nombres de contactos
        //    estan en mayusculas y los unicos blancos que pueden contener son 
        //    los separadores de nombre y apellidos y de apellidos entre si:
        //    se eliminan los blancos al principio y final de nombre y este se
        //    pasa a mayusculas
        Contacto nuevo = new Contacto(nombre.trim().toUpperCase(), telefono);
        
        // Tras haberlo filtrado, probar a insertar el contacto y mostrar el 
        // resultado por pantalla
        if (miAgenda.insertar(nuevo)) {
            System.out.println("A?adido contacto:\n" + nuevo + "\nTienes " 
                              + miAgenda.talla() + " contactos en la agenda.");
        }
        else {
            System.out.println("Imposible insertar contacto: " 
                               + "tu agenda esta llena."); 
        }
    }
        
    private static void recuperarTelefono(Agenda miAgenda, Scanner teclado) {
        String nombre;
        // Filtro de datos al leer el nombre del contacto cuyo telefono se 
        // quiere recuperar: puede estar compuesto por cualquier caracter,   
        // DEBE tener una longitud en el intervalo [1, 40], deben eliminarse    
        // los blancos que le preceden o siguen y debe pasarse a mayusculas
        do {
            System.out.print("Nombre del contacto del que quieres el tfno.? "); 
            nombre = teclado.nextLine();  
        } while (nombre.length() < 1 || nombre.length() > 40);
        nombre = nombre.trim().toUpperCase();
        
        // Tras haberlo filtrado, probar a recuperar el telefono de nombre y 
        // mostrar el resultado por pantalla
        String telefono = miAgenda.recuperar(nombre); 
        if (telefono != null) {
            System.out.println("El telefono de " + nombre + " es " + telefono); 
        }
        else {
            System.out.println("Imposible recuperar telefono: " + nombre 
                               + " no esta en tu agenda."); 
        }
    }
    
    private static void eliminarContacto(Agenda miAgenda, Scanner teclado) {
        String nombre;
        // Filtro de datos al leer nombre del contacto cuyo telefono se 
        // quiere eliminar: puede estar compuesto por cualquier caracter, 
        // DEBE tener una longitud en el intervalo [1, 40], deben eliminarse
        // los blancos que le preceden o siguen y debe pasarse a mayusculas
        do {
            System.out.print("Nombre del contacto que quieres eliminar? "); 
            nombre = teclado.nextLine();  
        } while (nombre.length() < 1 || nombre.length() > 40);
        nombre = nombre.trim().toUpperCase();
        
        // Tras haberlo filtrado, probar a eliminar el contacto con ese nombre  
        // y mostrar el resultado por pantalla
        boolean eliminado = miAgenda.eliminar(nombre);
        if (eliminado) {
            System.out.println("Contacto eliminado con exito."); 
        }
        else {
            System.out.println("Imposible eliminar contacto: " + nombre 
                               + " no esta en tu agenda."); 
        }
    }
}
