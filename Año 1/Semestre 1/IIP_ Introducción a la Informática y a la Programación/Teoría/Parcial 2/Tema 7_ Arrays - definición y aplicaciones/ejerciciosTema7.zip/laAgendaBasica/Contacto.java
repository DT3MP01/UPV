package laAgendaBasica;

/**
 * Clase Contacto: representa un contacto (basico) de una agenda, que TIENE 
 * un nombre y el telefono a el asociado
 * 
 * IMPORTANTE: para acceder a un telefono de la agenda es imprescindible buscar 
 * primero el nombre a el asociado, por lo que el nombre se puede considerar LA 
 * CLAVE de acceso a la informacion que contiene una agenda
 * 
 * @author IIP
 * @version Noviembre 2015-2016
 */

public class Contacto {
    
    // Un contacto TIENE UN ... 
    private String nombre, telefono;

    /**
     * Crea un contacto de nombre {@code n} y telefono {@code t}
     * 
     * @param n  un {@code String} 
     * @param t  un {@code String} 
     */
    public Contacto(String n, String t) {
        this.nombre = n; 
        this.telefono = t; 
    }
    
    /**
     * Devuelve el nombre de un contacto
     * 
     * @return el literal de {@code String} con el nombre de un contacto
     */
    public String getNombre() { return this.nombre; }
    
    /**
     * Devuelve el telefono de un contacto
     * 
     * @return el literal de {@code String} con el telefono de un contacto
     */
    public String getTelefono() { return this.telefono; }
    
    /**
     * Actualiza a {@code nuevo} el nombre de un contacto
     * 
     * @param nuevo  un {@code String} 
     */
    public void setNombre(String nuevo) { this.nombre = nuevo; }  
    
    /**
     * Actualiza a {@code nuevo} el telefono de un contacto
     * 
     * @param nuevo  un {@code String}
     */
    public void setTelefono(String nuevo) { this.telefono = nuevo; }
    
    /**
     * Comprueba si un contacto es igual a {@code otro}, i.e. si su nombre  
     * coincide con el de {@code otro} -claves de acceso a los respectivos
     * telefonos "equals"
     * 
     * Sobrescribe el metodo {@code equals} de {@code Object} 
     * 
     * @param otro  un {@code Object}
     * @return el valor {@code boolean} que resulta de comprobar la igualdad
     */
    public boolean equals(Object o) {
        return o instanceof Contacto 
               && this.nombre.equals(((Contacto) o).nombre);
    }
    
    /**
     * Devuelve el {@code String} que representa un contacto, 
     * i.e. a sus componentes en un formato dado
     * 
     * Sobrescribe el metodo {@code toString} de {@code Object}
     * 
     * @return el literal {@code String} con los datos de un contacto
     */
    public String toString() { 
        return "Nombre:   " + nombre + "\nTelefono: " + telefono; 
    }
}
