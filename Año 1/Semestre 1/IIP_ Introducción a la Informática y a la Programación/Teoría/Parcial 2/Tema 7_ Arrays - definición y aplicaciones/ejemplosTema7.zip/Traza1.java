/**
 * Primera traza del uso de arrays como parametros
 * 
 * @author IIP 
 * @version Noviembre 2015
 */

public class Traza1 {
    
    public static void main(String[] args) {
        int[] aux = {5, 1, 2, 4}; int j = aux[0];
        System.out.println("En main: " + j + " " + aux[0]);
        m2(aux, j);
        System.out.println("En main: " + j + " " + aux[0]);
    }
    
    private static void m2(int[] a, int v) {
        System.out.println("En m2: " + v + " " + a[0]);
        v++; a[0]++;
        m1(v, a);
        System.out.println("En m2: " + v + " " + a[0]);
    }
    
    private static void m1(int a, int[] v) {
        System.out.println("En m1: " + a + " " + v[0]);
        a++; v[0]++;
        System.out.println("En m1: " + a + " " + v[0]);
    }
}