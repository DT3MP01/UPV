/**
 * Primera traza del uso de arrays como parametros
 * 
 * @author IIP 
 * @version Noviembre 2015
 */

public class Traza2 {
    
    public static void main(String[] args) { 
        m1();
    }
    
    private static void m1() { 
        int[] a1 = new int[5];
        for (int i = 0; i < a1.length; i++) { a1[i] = i; }
        int p = 10;
        escribir(a1, p);
        m2(a1, p);
        escribir(a1, p);
    }
    
    private static void escribir(int[] e, int k) {
        for (int i = 0; i < e.length; i++) { System.out.print(e[i] + " - "); }
        System.out.println(k);
        System.out.println();
    }
    
    private static void m2(int[] v, int p) {
        
        for (int i = 0; i < v.length; i++) { v[i] = 2 * v[i]; }
        p = 2 * p;
    }
}
