/**
 * Arrays como parametros
 * 
 * @author IIP 
 * @version Noviembre 2015
 */

public class PasoParametros {
    public static void main(String[] args) {
        
        double[] elArray = {5.0, 6.4, 3.2, 0.0, 1.2};
        metodo1(elArray);
        // elArray no se ha modificado
        metodo2(elArray);
        // elArray{0] vale ahora 0.1
    }
    
    public static void metodo1(double[] copia) {
        copia = new double[5]; // desaparece al acabar el metodo
    }
    
    public static void metodo2(double[] copia) {
        copia[0] = 0.1; // modificado elArray[0]
    }
}
