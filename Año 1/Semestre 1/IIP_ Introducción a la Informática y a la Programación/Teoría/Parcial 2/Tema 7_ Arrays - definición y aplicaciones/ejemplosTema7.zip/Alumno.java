/**
 * Classe Alumno que representa a un alumno de un grupo 
 * de la EtsInf
 * 
 * @author IIP
 * @version Curs 2014/15
 */
public class Alumno {
    
    private long dni;
    private double nota;
    private String nombre;
    private boolean asistencia;
    private char grupo;
    
    /**
     * Crea un alumno a partir nombre y dni
     */
    public Alumno(String n, long dniDeN) {
        nombre = n; 
        dni = dniDeN;
        asistencia = true;
        nota = 0.0;
        grupo = ' ';
    }
    
    /** 
     * Devuelve el dni de un alumno
     */
    public long getDni() { return dni; }
    
    /** 
     * Devuelve la nota de la asignatura del alumno
     */
    public double getNota() { return nota; }
    
    /** 
     * Devuelve el nombre de un alumno
     */
    public String getNombre() { return nombre; }
    
    /** 
     * Devuelve la asistencia de un alumno, true si ha asistido
     * a clase y false en caso contrario
     */
    public boolean getAsistencia() { return asistencia; }
    
    /** 
     * Devuelve el grupo de matricula de un alumno
     */
    public char getGrupo() { return grupo; }
    
    /** 
     * Actualiza a nueva la nota de un alumno
     */
    public void setNota(double nueva) { nota = nueva; }
    
    /** 
     * Actualiza a nueva la asistencia de un alumno
     */
    public void setAsistencia(boolean nueva) { asistencia = nueva; }
    
    /** 
     * Actualiza a nuevo el grupo de matricula de un alumno
     */
    public void setGrupo(char nuevo) { grupo = nuevo; }
    
    /**
     * Devuelve un String con los datos de un alumno en 
     * un determinado formato
     */
    public String toString() {
        String res = "Nombre: " + nombre + "\tDni: " + dni 
                     + "\nGrupo: " + grupo + "  Nota: " + nota 
                     + " Asistencia: ";
        if (asistencia) { res += "sI"; }
        else { res += "no"; }
        return res;
    }
}
